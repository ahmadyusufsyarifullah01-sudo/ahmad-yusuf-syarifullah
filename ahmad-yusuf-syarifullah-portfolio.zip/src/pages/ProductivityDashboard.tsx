import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Play, Check, Clock, CloudSun, Calendar as CalIcon, 
  Github, BarChart2, BookOpen, MessageSquare, PlusCircle, CheckCircle, 
  Trash2, RefreshCw, AlertCircle, Sparkles, Star, Award, Zap, Code
} from 'lucide-react';
import { 
  Task, LearningLog, DashboardStats, Skill, Project, ContactMessage, NotificationItem 
} from '../types';

interface ProductivityDashboardProps {
  lang: 'en' | 'id';
  isAdmin: boolean;
  onLoginClick: () => void;
}

export default function ProductivityDashboard({ lang, isAdmin, onLoginClick }: ProductivityDashboardProps) {
  // Stats
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [logs, setLogs] = useState<LearningLog[]>([]);
  const [github, setGithub] = useState<any>(null);

  // Form states
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [logTopic, setLogTopic] = useState('');
  const [logHours, setLogHours] = useState(2);

  // Weather simulated state
  const [weather, setWeather] = useState({
    temp: 29,
    condition: 'Thunderstorm',
    humidity: 84,
    wind: 12,
    location: 'Yogyakarta, ID'
  });

  const [loading, setLoading] = useState(true);

  // Load everything
  const loadDashboardData = async () => {
    try {
      const [statsRes, tasksRes, logsRes, githubRes] = await Promise.all([
        fetch('/api/dashboard/stats'),
        fetch('/api/tasks'),
        fetch('/api/learning-logs'),
        fetch('/api/github')
      ]);

      if (statsRes.ok) setStats(await statsRes.ok ? await statsRes.json() : null);
      if (tasksRes.ok) setTasks(await tasksRes.json());
      if (logsRes.ok) setLogs(await logsRes.json());
      if (githubRes.ok) setGithub(await githubRes.json());
    } catch (e) {
      console.error('Error fetching dashboard records:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  // Quick Action: Add task
  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle) return;

    // We can add tasks client-side or hit Express API
    // Let's call Express API with requireAuth (if isAdmin) or let user add locally (we handle it beautifully!)
    // To ensure fluid UX, we'll allow anyone to submit tasks on the dashboard! It creates a wonderful interactive playground.
    // In our backend, requireAuth is enabled for safety. So if they are logged in, we submit to API, or otherwise we let them save locally in state for instant responsiveness!
    const token = localStorage.getItem('portfolio_admin_token');
    if (token) {
      try {
        const res = await fetch('/api/tasks', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            title: newTaskTitle,
            priority: newTaskPriority,
            status: 'todo'
          })
        });
        if (res.ok) {
          setNewTaskTitle('');
          loadDashboardData();
        }
      } catch (err) {
        console.error(err);
      }
    } else {
      // Offline fallback state update so non-logged-in users can play with it too!
      const fallbackTask: Task = {
        id: `offline-t-${Date.now()}`,
        title: newTaskTitle,
        priority: newTaskPriority,
        status: 'todo',
        createdAt: new Date().toISOString()
      };
      setTasks([fallbackTask, ...tasks]);
      setNewTaskTitle('');
    }
  };

  // Quick Action: Update task status
  const handleUpdateTaskStatus = async (id: string, newStatus: 'todo' | 'in_progress' | 'done') => {
    const token = localStorage.getItem('portfolio_admin_token');
    if (token && !id.startsWith('offline-')) {
      try {
        const res = await fetch(`/api/tasks/${id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ status: newStatus })
        });
        if (res.ok) {
          loadDashboardData();
        }
      } catch (err) {
        console.error(err);
      }
    } else {
      // Local fallbacks
      setTasks(tasks.map(t => t.id === id ? { ...t, status: newStatus } : t));
    }
  };

  // Quick Action: Add study logs
  const handleAddStudyLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!logTopic) return;

    const token = localStorage.getItem('portfolio_admin_token');
    if (token) {
      try {
        const res = await fetch('/api/learning-logs', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            topic: logTopic,
            hours: logHours,
            date: new Date().toISOString().split('T')[0]
          })
        });
        if (res.ok) {
          setLogTopic('');
          loadDashboardData();
        }
      } catch (e) {
        console.error(e);
      }
    } else {
      const fallbackLog: LearningLog = {
        id: `offline-l-${Date.now()}`,
        topic: logTopic,
        hours: Number(logHours),
        date: new Date().toISOString().split('T')[0]
      };
      setLogs([fallbackLog, ...logs]);
      setLogTopic('');
    }
  };

  // Simulate weather refresh
  const handleWeatherRefresh = () => {
    const temps = [28, 29, 30, 31, 32];
    const conditions = ['Thunderstorm', 'Heavy Rain', 'Overcast', 'Scattered Clouds'];
    setWeather({
      ...weather,
      temp: temps[Math.floor(Math.random() * temps.length)],
      condition: conditions[Math.floor(Math.random() * conditions.length)],
      humidity: Math.floor(Math.random() * 10) + 80
    });
  };

  return (
    <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid-bg relative z-10 min-h-screen">
      
      {/* Header and Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-12 gap-4">
        <div>
          <span className="font-mono text-xs text-red-500 uppercase tracking-widest font-semibold mb-2">TELEMETRY & LOGISTICS HUB</span>
          <h1 className="font-display font-extrabold text-3xl sm:text-5xl text-white">
            {lang === 'en' ? 'Productivity Engine' : 'Pusat Produktivitas'}
          </h1>
        </div>
        
        <div className="flex items-center space-x-3">
          {!isAdmin && (
            <div className="text-xs font-mono text-zinc-500 border border-zinc-900 rounded-lg bg-zinc-950/40 p-2.5 flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-500/80 animate-pulse" />
              <span>{lang === 'en' ? 'Sign in as Admin to sync database persistently.' : 'Masuk sebagai Admin untuk sinkronisasi permanen.'}</span>
              <button onClick={onLoginClick} className="text-red-500 hover:underline font-semibold uppercase tracking-wider ml-1">
                Login
              </button>
            </div>
          )}
          <button 
            onClick={loadDashboardData}
            className="p-2.5 border border-zinc-800 hover:border-red-500/30 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-900/60 transition-all cursor-pointer"
            title="Refresh Data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* METRICS ROW BENTO COMPONENT */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        
        <div className="glass-card border border-zinc-900/80 p-5 rounded-2xl flex items-center space-x-4 relative overflow-hidden shadow-xl">
          <div className="p-3 bg-red-950/20 border border-red-500/20 rounded-xl text-red-500">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <p className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest">{lang === 'en' ? 'Study Hours' : 'Jam Belajar'}</p>
            <h3 className="font-display font-bold text-2xl text-white mt-1">
              {stats ? stats.learningHoursThisWeek : logs.reduce((a, b) => a + b.hours, 0)} hrs
            </h3>
          </div>
        </div>

        <div className="glass-card border border-zinc-900/80 p-5 rounded-2xl flex items-center space-x-4 relative overflow-hidden shadow-xl">
          <div className="p-3 bg-red-950/20 border border-red-500/20 rounded-xl text-red-500">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <p className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest">{lang === 'en' ? 'Tasks Done' : 'Tugas Selesai'}</p>
            <h3 className="font-display font-bold text-2xl text-white mt-1">
              {stats ? stats.completedTasks : tasks.filter(t => t.status === 'done').length} completed
            </h3>
          </div>
        </div>

        <div className="glass-card border border-zinc-900/80 p-5 rounded-2xl flex items-center space-x-4 relative overflow-hidden shadow-xl">
          <div className="p-3 bg-red-950/20 border border-red-500/20 rounded-xl text-red-500">
            <Github className="w-5 h-5" />
          </div>
          <div>
            <p className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest">Commits This Month</p>
            <h3 className="font-display font-bold text-2xl text-white mt-1">
              {github ? github.contributionStats.totalCommitsThisMonth : 142} commits
            </h3>
          </div>
        </div>

        <div className="glass-card border border-zinc-900/80 p-5 rounded-2xl flex items-center space-x-4 relative overflow-hidden shadow-xl">
          <div className="p-3 bg-red-950/20 border border-red-500/20 rounded-xl text-red-500">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <p className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest">{lang === 'en' ? 'Inbox Messages' : 'Pesan Masuk'}</p>
            <h3 className="font-display font-bold text-2xl text-white mt-1">
              {stats ? stats.unreadMessagesCount : 0} unread
            </h3>
          </div>
        </div>
      </div>

      {/* SECOND ROW BENTO CONTAINER */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start mb-8">
        
        {/* TASK MANAGEMENT LIST PANEL (lg:col-span-8) */}
        <div className="lg:col-span-8 glass-card border border-zinc-900 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-zinc-900">
            <div className="flex items-center space-x-2">
              <CheckCircle className="text-red-500 w-5 h-5" />
              <h3 className="font-display font-extrabold text-lg text-white">
                {lang === 'en' ? 'Kanban Task Board' : 'Papan Tugas Kanban'}
              </h3>
            </div>
            <span className="font-mono text-[10px] bg-red-950/30 text-red-500 border border-red-500/25 px-2 py-0.5 rounded uppercase">
              {tasks.filter(t => t.status !== 'done').length} pending
            </span>
          </div>

          {/* Quick Task Adding Form */}
          <form onSubmit={handleAddTask} className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder={lang === 'en' ? 'Input a new productivity milestone...' : 'Ketik target produktivitas baru...'}
              className="flex-grow bg-zinc-900/85 border border-zinc-850 rounded-lg px-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-red-500"
            />
            <div className="flex gap-2">
              <select
                value={newTaskPriority}
                onChange={(e) => setNewTaskPriority(e.target.value as any)}
                className="bg-zinc-900 border border-zinc-850 rounded-lg px-3 py-2 text-xs text-zinc-400 font-mono"
              >
                <option value="low">LOW</option>
                <option value="medium">MEDIUM</option>
                <option value="high">HIGH</option>
              </select>
              <button
                type="submit"
                className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-mono text-[10px] font-bold tracking-wider uppercase rounded-lg flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </form>

          {/* Tasks categorization list column grids */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            {/* TODO COLUMN */}
            <div className="space-y-3 bg-zinc-900/10 p-3 rounded-xl border border-zinc-900/60">
              <h4 className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest font-bold flex items-center justify-between">
                <span>Todo</span>
                <span className="bg-zinc-900 px-1.5 py-0.5 rounded">{tasks.filter(t => t.status === 'todo').length}</span>
              </h4>
              <div className="space-y-2">
                {tasks.filter(t => t.status === 'todo').map(task => (
                  <div key={task.id} className="p-3 bg-zinc-900/50 border border-zinc-850/60 rounded-lg text-xs space-y-3 shadow-inner">
                    <p className="text-zinc-200 leading-normal font-sans font-medium">{task.title}</p>
                    <div className="flex justify-between items-center text-[10px] font-mono">
                      <span className={`px-1.5 py-0.5 rounded text-[8px] uppercase font-bold ${
                        task.priority === 'high' ? 'bg-red-950/30 text-red-500' : task.priority === 'medium' ? 'bg-amber-950/30 text-amber-500' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {task.priority}
                      </span>
                      <button 
                        onClick={() => handleUpdateTaskStatus(task.id, 'in_progress')}
                        className="text-red-500 hover:underline flex items-center space-x-0.5"
                      >
                        <Play className="w-3 h-3" />
                        <span>Start</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* IN PROGRESS COLUMN */}
            <div className="space-y-3 bg-zinc-900/10 p-3 rounded-xl border border-zinc-900/60">
              <h4 className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest font-bold flex items-center justify-between">
                <span>In Progress</span>
                <span className="bg-zinc-900 px-1.5 py-0.5 rounded">{tasks.filter(t => t.status === 'in_progress').length}</span>
              </h4>
              <div className="space-y-2">
                {tasks.filter(t => t.status === 'in_progress').map(task => (
                  <div key={task.id} className="p-3 bg-zinc-900/50 border border-red-900/20 rounded-lg text-xs space-y-3 shadow-inner">
                    <p className="text-zinc-200 leading-normal font-sans font-medium">{task.title}</p>
                    <div className="flex justify-between items-center text-[10px] font-mono">
                      <span className={`px-1.5 py-0.5 rounded text-[8px] uppercase font-bold ${
                        task.priority === 'high' ? 'bg-red-950/30 text-red-500' : task.priority === 'medium' ? 'bg-amber-950/30 text-amber-500' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {task.priority}
                      </span>
                      <button 
                        onClick={() => handleUpdateTaskStatus(task.id, 'done')}
                        className="text-emerald-500 hover:underline flex items-center space-x-0.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Complete</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* DONE COLUMN */}
            <div className="space-y-3 bg-zinc-900/10 p-3 rounded-xl border border-zinc-900/60">
              <h4 className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest font-bold flex items-center justify-between">
                <span>Done</span>
                <span className="bg-zinc-900 px-1.5 py-0.5 rounded">{tasks.filter(t => t.status === 'done').length}</span>
              </h4>
              <div className="space-y-2">
                {tasks.filter(t => t.status === 'done').map(task => (
                  <div key={task.id} className="p-3 bg-zinc-900/20 border border-zinc-900/80 rounded-lg text-xs space-y-2 opacity-65">
                    <p className="text-zinc-400 line-through leading-normal font-sans">{task.title}</p>
                    <div className="flex items-center space-x-1.5 text-[9px] font-mono text-emerald-500/80">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>COMPLETED</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* STUDY LOGS BAR GRAPH & STATS (lg:col-span-4) */}
        <div className="lg:col-span-4 glass-card border border-zinc-900 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="pb-4 border-b border-zinc-900 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BarChart2 className="text-red-500 w-5 h-5" />
              <h3 className="font-display font-extrabold text-lg text-white">
                {lang === 'en' ? 'Study Tracker' : 'Pencatat Belajar'}
              </h3>
            </div>
          </div>

          {/* Graphical custom bar representation (No complex SVG lib needed, custom React is cleaner and highly robust) */}
          <div className="space-y-4">
            <div className="h-44 flex items-end justify-between px-2 bg-zinc-950/80 border border-zinc-900 rounded-xl py-4 relative">
              <div className="absolute inset-0 grid-bg opacity-10" />
              {logs.slice(0, 5).reverse().map((log) => {
                const maxHours = 8;
                const percentage = Math.min(100, (log.hours / maxHours) * 100);
                return (
                  <div key={log.id} className="flex flex-col items-center space-y-2 group z-10 w-full">
                    <div className="text-[10px] font-mono text-red-500 font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                      {log.hours}h
                    </div>
                    <div className="w-4 bg-zinc-900 border border-zinc-850 rounded-t-sm h-28 flex items-end">
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: `${percentage}%` }}
                        className="bg-red-600 group-hover:bg-red-500 w-full rounded-t-sm shadow-[0_0_8px_rgba(239,68,68,0.3)] transition-colors"
                      />
                    </div>
                    <span className="font-mono text-[8px] text-zinc-500 truncate max-w-full" title={log.topic}>
                      {log.topic.substring(0, 5)}...
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Quick Study Logging Form */}
            <form onSubmit={handleAddStudyLog} className="space-y-3.5 bg-zinc-900/10 border border-zinc-900/60 p-4 rounded-xl">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest block font-bold">Topic</label>
                  <input
                    type="text"
                    value={logTopic}
                    onChange={(e) => setLogTopic(e.target.value)}
                    placeholder="Three.js, Larv, etc"
                    className="w-full bg-zinc-900 border border-zinc-850 rounded px-2.5 py-1.5 text-xs text-zinc-300"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest block font-bold">Hours</label>
                  <input
                    type="number"
                    value={logHours}
                    min={1}
                    max={12}
                    onChange={(e) => setLogHours(Number(e.target.value))}
                    className="w-full bg-zinc-900 border border-zinc-850 rounded px-2.5 py-1.5 text-xs text-zinc-300"
                  />
                </div>
              </div>
              <button
                type="submit"
                className="w-full py-2 bg-red-600/15 border border-red-500/25 hover:bg-red-600 hover:text-white text-red-500 font-mono text-[9px] font-bold tracking-widest uppercase rounded flex items-center justify-center space-x-1 cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Log Study Session</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* THIRD ROW BENTO CONTAINER */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* GITHUB ACTIVITY CALENDAR (md:col-span-8) */}
        <div className="md:col-span-8 glass-card border border-zinc-900 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-zinc-900">
            <div className="flex items-center space-x-2.5">
              <Github className="text-white w-5 h-5" />
              <div>
                <h3 className="font-display font-extrabold text-lg text-white">
                  GitHub Contribution Stream
                </h3>
                <p className="text-[10px] text-zinc-500 font-mono">ahmadyusufsyarifullah01-sudo // active-commits</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {/* Git activity contribution boxes representer */}
            <div className="p-4 bg-zinc-950/80 border border-zinc-900 rounded-xl">
              <div className="flex justify-between text-[9px] font-mono text-zinc-600 mb-2">
                <span>June 2026</span>
                <span>Active Streak: {github ? github.contributionStats.activeDaysStreak : 21} days</span>
              </div>
              
              {/* Contribution grid blocks */}
              <div className="flex flex-wrap gap-1.5">
                {Array.from({ length: 56 }).map((_, i) => {
                  // Generate random shades of red/zinc to simulate contributions
                  const intensities = [
                    'bg-zinc-900/60', // empty
                    'bg-red-950/40', // light
                    'bg-red-900/60', // medium
                    'bg-red-700/80', // active
                    'bg-red-500 shadow-[0_0_5px_rgba(239,68,68,0.25)]' // heavy
                  ];
                  let idx = 0;
                  if (i % 3 === 0) idx = 1;
                  if (i % 5 === 0) idx = 2;
                  if (i % 7 === 0) idx = 3;
                  if (i % 11 === 0) idx = 4;
                  return (
                    <div 
                      key={i} 
                      className={`w-3.5 h-3.5 rounded-sm transition-transform hover:scale-110 cursor-pointer ${intensities[idx]}`} 
                      title={`Commits registered: ${idx * 2}`}
                    />
                  );
                })}
              </div>
            </div>

            {/* Repositories linked list */}
            <div className="space-y-2.5">
              <h4 className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest font-bold">Synchronized Repositories</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(github?.repos || [
                  { name: 'ahmad-yusuf-syarifullah', stars: 24, language: 'TypeScript' },
                  { name: 'aura-luxury-store', stars: 18, language: 'TypeScript' }
                ]).map((repo: any, idx: number) => (
                  <div key={idx} className="p-3 bg-zinc-900/30 border border-zinc-900 rounded-lg flex items-center justify-between">
                    <div>
                      <h5 className="font-display font-semibold text-white text-xs truncate max-w-[150px]">{repo.name}</h5>
                      <span className="font-mono text-[8px] text-zinc-500 uppercase">{repo.language}</span>
                    </div>
                    <div className="flex items-center space-x-1 font-mono text-[10px] text-red-500">
                      <Star className="w-3.5 h-3.5" />
                      <span>{repo.stars}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* WEATHER TELEMETRY WIDGET (md:col-span-4) */}
        <div className="md:col-span-4 glass-card border border-zinc-900 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div className="flex justify-between items-start pb-4 border-b border-zinc-900">
            <div className="flex items-center space-x-2">
              <CloudSun className="text-red-500 w-5 h-5" />
              <h3 className="font-display font-extrabold text-base text-white">
                HQ Telemetry
              </h3>
            </div>
            <button 
              onClick={handleWeatherRefresh}
              className="p-1 border border-zinc-850 hover:border-red-500/30 text-zinc-500 hover:text-white rounded transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>

          <div className="py-6 flex flex-col items-center text-center space-y-2">
            <h4 className="font-display font-bold text-5xl text-white tracking-tight">
              {weather.temp}°C
            </h4>
            <p className="text-red-500 font-mono text-[11px] font-bold tracking-widest uppercase">
              {weather.condition}
            </p>
            <p className="text-zinc-500 font-sans text-xs">
              Yogyakarta, Indonesia
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-4 border-t border-zinc-900 font-mono text-[10px] text-zinc-500">
            <div className="p-2.5 bg-zinc-900/40 rounded-lg border border-zinc-900/60">
              <span className="block uppercase tracking-wider text-[8px]">HUMIDITY</span>
              <span className="text-zinc-300 font-bold mt-0.5 block">{weather.humidity}%</span>
            </div>
            <div className="p-2.5 bg-zinc-900/40 rounded-lg border border-zinc-900/60">
              <span className="block uppercase tracking-wider text-[8px]">WIND FORCE</span>
              <span className="text-zinc-300 font-bold mt-0.5 block">{weather.wind} km/h</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
