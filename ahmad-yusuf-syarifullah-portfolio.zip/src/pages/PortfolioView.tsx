import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Briefcase, GraduationCap, ExternalLink, Github, Search, 
  Layers, Star, Calendar, FileText, Map, Award, Image as ImageIcon, 
  MapPin, CheckSquare, ArrowDown, Instagram, MapPinned
} from 'lucide-react';
import Hero from '../components/Hero';
import ContactForm from '../components/ContactForm';
import { 
  Profile, Skill, Project, Certificate, Experience, Education, GalleryItem 
} from '../types';

interface PortfolioViewProps {
  profile: Profile;
  lang: 'en' | 'id';
  onNewMessageSent: () => void;
  onNavigateTab: (tab: string) => void;
}

export default function PortfolioView({ profile, lang, onNewMessageSent, onNavigateTab }: PortfolioViewProps) {
  // Database collections loaded from APIs
  const [skills, setSkills] = useState<Skill[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [experiences, setExperiences] = useState<Experience[]>([]);
  const [education, setEducation] = useState<Education[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);

  // Filtering states
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [projectSearch, setProjectSearch] = useState('');

  // Fetch all database records
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [sRes, pRes, cRes, eRes, edRes, gRes] = await Promise.all([
          fetch('/api/skills'),
          fetch('/api/projects'),
          fetch('/api/certificates'),
          fetch('/api/experiences'),
          fetch('/api/education'),
          fetch('/api/gallery')
        ]);

        if (sRes.ok) setSkills(await sRes.json());
        if (pRes.ok) setProjects(await pRes.json());
        if (cRes.ok) setCertificates(await cRes.json());
        if (eRes.ok) setExperiences(await eRes.json());
        if (edRes.ok) setEducation(await edRes.json());
        if (gRes.ok) setGallery(await gRes.json());
      } catch (err) {
        console.error('Error fetching portfolio data:', err);
      }
    };

    fetchData();
  }, []);

  // Filter project lists
  const projectCategories = ['All', ...Array.from(new Set(projects.map(p => p.category)))];
  
  const filteredProjects = projects.filter(proj => {
    const matchesCategory = selectedCategory === 'All' || proj.category === selectedCategory;
    const matchesSearch = proj.title.toLowerCase().includes(projectSearch.toLowerCase()) || 
                          proj.description.toLowerCase().includes(projectSearch.toLowerCase()) ||
                          proj.tags.some(tag => tag.toLowerCase().includes(projectSearch.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="relative w-full overflow-hidden">
      
      {/* 1. HERO HOME VIEWPORT */}
      <Hero 
        profile={profile} 
        onNavigate={(tab) => {
          const tabEl = document.getElementById(tab);
          if (tabEl) tabEl.scrollIntoView({ behavior: 'smooth' });
        }}
        lang={lang}
      />

      {/* SECTION NAV SNAP LINE */}
      <div className="w-full flex justify-center py-6 border-b border-white/5 relative z-10 bg-white/[0.01]">
        <button 
          onClick={() => document.getElementById('about-me')?.scrollIntoView({ behavior: 'smooth' })}
          className="text-white/40 hover:text-[#FF3333] font-mono text-[10px] tracking-widest uppercase flex items-center space-x-2 animate-bounce cursor-pointer"
        >
          <span>{lang === 'en' ? 'SCROLL DOWN TO REVEAL' : 'GULIR KE BAWAH UNTUK MELIHAT'}</span>
          <ArrowDown className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 2. ABOUT ME SECTION */}
      <section id="about-me" className="py-24 sm:py-32 relative z-10 grid-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center lg:text-left mb-16">
            <h3 className="font-mono text-xs text-[#FF3333] uppercase tracking-widest font-bold mb-2">01 // IDENTITY DEFINITION</h3>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white">
              {lang === 'en' ? 'Architecting Modern Solutions' : 'Merancang Solusi Modern'}
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Bio Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-[#0D0D0D] border border-white/5 rounded-xl p-6 sm:p-8 space-y-4 shadow-xl">
                <p className="text-white/80 font-light leading-relaxed text-base sm:text-lg">
                  {lang === 'en' 
                    ? `I am ${profile.name}, a dedicated Full Stack Developer and UI/UX Engineer with an unwavering focus on code craftsmanship, architectural modularity, and pixel perfection. I believe software should be as elegant internally as it is responsive externally.`
                    : `Saya ${profile.name}, seorang Full Stack Developer dan UI/UX Engineer yang berdedikasi dengan fokus penuh pada keindahan kode, modularitas arsitektur, dan keselarasan piksel. Saya percaya bahwa perangkat lunak harus seanggun internalnya sebagaimana responsif eksternalnya.`}
                </p>
                <p className="text-white/60 font-light leading-relaxed text-sm">
                  {lang === 'en'
                    ? 'Through years of working with agile engineering teams and international clients, I have solidified my expertise in building high-performance Node.js architectures, secure database pipelines, automated CI/CD infrastructures, and responsive frontend screens.'
                    : 'Melalui pengalaman bertahun-tahun bekerja dengan tim teknik yang lincah dan klien internasional, saya telah memantapkan keahlian saya dalam membangun arsitektur Node.js berkinerja tinggi, pipa database yang aman, infrastruktur CI/CD otomatis, dan layar frontend responsif.'}
                </p>
              </div>

              {/* Education Grid Card inside about */}
              <div className="space-y-4">
                <h4 className="font-mono text-xs text-white/40 uppercase tracking-widest font-semibold pl-1 flex items-center space-x-2">
                  <GraduationCap className="w-4 h-4 text-[#FF3333]" />
                  <span>{lang === 'en' ? 'Education Credentials' : 'Kredensial Pendidikan'}</span>
                </h4>
                {education.map((edu) => (
                  <div key={edu.id} className="bg-[#0D0D0D]/50 border border-white/5 rounded-xl p-5 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                    <div>
                      <h5 className="font-display font-bold text-white text-base">{edu.degree} in {edu.field}</h5>
                      <p className="text-white/40 text-xs font-mono">{edu.institution}</p>
                    </div>
                    <div className="text-left sm:text-right">
                      <p className="text-white/50 font-mono text-xs">{edu.startDate.split('-')[0]} - {edu.endDate.split('-')[0]}</p>
                      {edu.gpa && <p className="text-[#FF3333] font-mono text-[11px] mt-0.5">GPA: {edu.gpa}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Metrics & Location Sidebar */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Instagram Card public profile mock up (yunzanigeng) */}
              <a 
                href="https://instagram.com/yunzanigeng" 
                target="_blank" 
                rel="noreferrer"
                className="block bg-[#0D0D0D] border border-white/5 hover:border-[#FF3333]/30 rounded-xl p-6 shadow-xl relative group overflow-hidden transition-all duration-300"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-tr from-pink-500/5 to-purple-500/5 rounded-full blur-2xl group-hover:scale-125 transition-transform" />
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 p-[2px]">
                      <div className="w-full h-full rounded-full bg-zinc-950 flex items-center justify-center overflow-hidden">
                        <span className="text-white font-bold text-xs font-mono">YZ</span>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-white text-sm">yunzanigeng</h4>
                      <p className="text-white/40 font-mono text-[10px] tracking-wider uppercase">Instagram Connection</p>
                    </div>
                  </div>
                  <Instagram className="w-5 h-5 text-[#FF3333]" />
                </div>
                <p className="text-white/60 text-xs leading-relaxed font-sans mb-3">
                  {lang === 'en' ? 'Syncing visual design artifacts, UI updates, and creative lifestyle updates.' : 'Sinkronisasi desain visual, pembaruan UI, dan gaya hidup kreatif.'}
                </p>
                <div className="flex space-x-4 text-xs text-white/40 font-mono">
                  <span><strong>1.4k</strong> followers</span>
                  <span><strong>512</strong> following</span>
                </div>
              </a>

              {/* Geo location cards */}
              <div className="bg-[#0D0D0D] border border-white/5 rounded-xl p-6 space-y-4">
                <div className="flex items-center space-x-3 text-[#FF3333]">
                  <MapPin className="w-5 h-5" />
                  <span className="font-mono text-xs uppercase tracking-wider font-semibold text-white/85">HQ Coordinate Hub</span>
                </div>
                <div className="aspect-video w-full rounded-xl bg-[#0A0A0A] border border-white/5 relative overflow-hidden flex items-center justify-center">
                  {/* Visual simulated vector map layer */}
                  <div className="absolute inset-0 grid-bg opacity-30" />
                  <div className="absolute w-24 h-24 bg-[#FF3333]/10 rounded-full animate-ping blur-md" />
                  <div className="relative z-10 flex flex-col items-center space-y-1 text-center px-4">
                    <MapPinned className="w-8 h-8 text-[#FF3333] mb-1" />
                    <span className="font-display font-bold text-white text-sm">Yogyakarta, ID</span>
                    <span className="font-mono text-[9px] text-white/40">7.7956° S, 110.3695° E</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. PROJECTS SHOWCASE */}
      <section id="projects-showcase" className="py-24 bg-[#0A0A0A] relative z-10 border-t border-white/5 grid-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row justify-between items-center mb-16 gap-6">
            <div className="text-center md:text-left">
              <h3 className="font-mono text-xs text-[#FF3333] uppercase tracking-widest font-bold mb-2">02 // PORTFOLIO ENTRIES</h3>
              <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white">
                {lang === 'en' ? 'Selected Deployments' : 'Proyek Pilihan'}
              </h2>
            </div>

            {/* SEARCH BAR */}
            <div className="relative w-full md:w-80">
              <input
                type="text"
                value={projectSearch}
                onChange={(e) => setProjectSearch(e.target.value)}
                placeholder={lang === 'en' ? 'Search projects or tags...' : 'Cari proyek atau tag...'}
                className="w-full bg-[#0D0D0D] border border-white/10 rounded-full px-5 py-2.5 pl-11 text-xs text-white focus:outline-none focus:border-[#FF3333] focus:ring-1 focus:ring-[#FF3333]/15 transition-all shadow-inner"
              />
              <Search className="w-4 h-4 text-white/40 absolute left-4 top-3" />
            </div>
          </div>

          {/* CATEGORY FILTER TABS */}
          <div className="flex flex-wrap justify-center sm:justify-start gap-2 mb-12">
            {projectCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-full font-mono text-[10px] uppercase tracking-wider transition-all duration-300 ${
                  selectedCategory === cat
                    ? 'bg-[#FF3333] text-white shadow-[0_0_12px_rgba(255,51,51,0.3)]'
                    : 'bg-[#0D0D0D]/60 text-white/50 border border-white/5 hover:text-white hover:border-white/10'
                }`}
              >
                {cat === 'All' ? (lang === 'en' ? 'ALL ARCHIVES' : 'SEMUA ARSIP') : cat}
              </button>
            ))}
          </div>

          {/* DYNAMIC PROJECTS GRID */}
          <AnimatePresence mode="popLayout">
            <motion.div 
              id="projects-grid"
              layout
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
            >
              {filteredProjects.map((proj) => (
                <motion.div
                  key={proj.id}
                  layout
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ duration: 0.35 }}
                  className="bg-[#0D0D0D] border border-white/5 hover:border-[#FF3333]/20 rounded-xl overflow-hidden shadow-xl flex flex-col h-full group"
                >
                  {/* Card Visual Header */}
                  <div className="aspect-video w-full bg-[#0A0A0A] relative overflow-hidden flex items-center justify-center border-b border-white/5">
                    <div className="absolute inset-0 grid-bg opacity-20" />
                    {/* Glowing Red Orbs behind details */}
                    <div className="absolute w-32 h-32 bg-[#FF3333]/5 rounded-full blur-2xl group-hover:bg-[#FF3333]/10 transition-colors duration-500" />
                    
                    {/* Floating logo representations or visual screenshot */}
                    {proj.image ? (
                      <img src={proj.image} alt={proj.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    ) : (
                      <div className="flex flex-col items-center justify-center p-6 text-center z-10">
                        <Layers className="w-12 h-12 text-[#FF3333]/70 mb-2 group-hover:scale-110 transition-transform" />
                        <span className="font-mono text-[9px] tracking-widest text-white/30 uppercase">SYS_PORT_MODULE // {proj.category}</span>
                      </div>
                    )}

                    {/* Featured ribbon */}
                    {proj.featured && (
                      <div className="absolute top-3 right-3 bg-[#FF3333]/15 border border-[#FF3333]/30 px-2.5 py-1 rounded font-mono text-[9px] text-[#FF3333] tracking-wider font-semibold uppercase">
                        Featured
                      </div>
                    )}
                  </div>

                  {/* Card Text Content */}
                  <div className="p-6 flex flex-col flex-grow space-y-4">
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-mono tracking-widest uppercase text-white/40">
                        {proj.category}
                      </span>
                      <h4 className="font-display font-bold text-white text-lg group-hover:text-[#FF3333] transition-colors">
                        {proj.title}
                      </h4>
                    </div>

                    <p className="text-white/60 text-xs font-light leading-relaxed flex-grow">
                      {proj.description}
                    </p>

                    {/* Tech Badges */}
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {proj.tags.map(tag => (
                        <span key={tag} className="px-2 py-0.5 rounded bg-white/5 border border-white/5 font-mono text-[9px] text-white/50">
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Link Actions */}
                    <div className="flex items-center space-x-3 pt-3 border-t border-white/5 mt-auto">
                      {proj.githubUrl && (
                        <a 
                          href={proj.githubUrl} 
                          target="_blank" 
                          rel="noreferrer" 
                          className="p-2 border border-white/5 hover:border-[#FF3333]/30 rounded-lg text-white/60 hover:text-white hover:bg-[#FF3333]/10 transition-all flex items-center space-x-1.5 text-xs font-mono"
                          title="View Repository"
                        >
                          <Github className="w-4 h-4" />
                          <span>Code</span>
                        </a>
                      )}
                      {proj.demoUrl && (
                        <a 
                          href={proj.demoUrl} 
                          target="_blank" 
                          rel="noreferrer" 
                          className="p-2 bg-white/5 border border-white/5 hover:border-[#FF3333]/30 rounded-lg text-[#FF3333] hover:text-white hover:bg-[#FF3333] transition-all flex items-center space-x-1.5 text-xs font-mono ml-auto"
                          title="Launch live portal demo"
                        >
                          <span>Launch</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}

              {filteredProjects.length === 0 && (
                <div className="col-span-full text-center py-16 text-white/40 font-mono text-xs">
                  NO DEPLOYMENTS FOUND MATCHING QUERY
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* 4. SKILLS & EXPERIENCE TIMELINE */}
      <section id="experience-skills" className="py-24 relative z-10 border-t border-white/5 grid-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
            
            {/* Skills Progress Dashboard Column */}
            <div className="lg:col-span-6 space-y-8">
              <div>
                <h3 className="font-mono text-xs text-[#FF3333] uppercase tracking-widest font-bold mb-2">03 // TECHNICAL EXPERTISE</h3>
                <h2 className="font-display font-extrabold text-3xl text-white">
                  {lang === 'en' ? 'Core Capabilities' : 'Kemampuan Teknis'}
                </h2>
              </div>

              {/* Skills rating grids grouped by categories */}
              <div className="space-y-6">
                {['Frontend', 'Backend', 'Database', 'DevOps', 'Tools'].map((cat) => {
                  const catSkills = skills.filter(s => s.category === cat);
                  if (catSkills.length === 0) return null;

                  return (
                    <div key={cat} className="space-y-3">
                      <h4 className="font-mono text-[10px] tracking-widest text-white/40 uppercase font-bold pl-1">{cat} Technologies</h4>
                      <div className="space-y-3.5 bg-[#0D0D0D]/50 border border-white/5 rounded-xl p-4">
                        {catSkills.map((skill) => (
                          <div key={skill.id} className="space-y-1.5">
                            <div className="flex justify-between text-xs font-mono">
                              <span className="text-white/80 font-semibold">{skill.name}</span>
                              <span className="text-[#FF3333]">{skill.level}%</span>
                            </div>
                            <div className="w-full bg-[#0A0A0A] border border-white/5 h-2 rounded-full overflow-hidden relative">
                              <motion.div
                                initial={{ width: 0 }}
                                whileInView={{ width: `${skill.level}%` }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.8, ease: 'easeOut' }}
                                className="h-full bg-gradient-to-r from-[#FF3333] to-[#FF3333] rounded-full shadow-[0_0_6px_rgba(255,51,51,0.4)]"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Experience Timeline Column */}
            <div className="lg:col-span-6 space-y-8">
              <div>
                <h3 className="font-mono text-xs text-[#FF3333] uppercase tracking-widest font-bold mb-2">04 // HISTORIC TIMELINE</h3>
                <h2 className="font-display font-extrabold text-3xl text-white">
                  {lang === 'en' ? 'Professional Milestones' : 'Pengalaman Profesional'}
                </h2>
              </div>

              {/* Timeline cards */}
              <div className="relative border-l border-white/5 pl-6 ml-3 space-y-8">
                {experiences.map((exp) => (
                  <div key={exp.id} className="relative space-y-2">
                    
                    {/* Circle Dot Marker */}
                    <div className="absolute top-1.5 -left-[31px] w-2.5 h-2.5 rounded-full border border-[#FF3333] bg-[#0A0A0A] shadow-[0_0_8px_rgba(255,51,51,0.7)]" />

                    <div className="bg-[#0D0D0D] border border-white/5 rounded-xl p-5 hover:border-[#FF3333]/10 transition-colors relative overflow-hidden group">
                      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-tr from-[#FF3333]/5 to-transparent rounded-full blur-lg" />
                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-1">
                        <span className="font-mono text-[10px] text-[#FF3333] font-bold tracking-wider uppercase flex items-center space-x-1">
                          <Calendar className="w-3.5 h-3.5 mr-1" />
                          <span>{exp.startDate.split('-')[0]} - {exp.current ? 'PRESENT' : exp.endDate.split('-')[0]}</span>
                        </span>
                        <span className="font-mono text-[9px] text-white/30 uppercase">{exp.location}</span>
                      </div>
                      <h4 className="font-display font-bold text-white text-base mt-2">{exp.role}</h4>
                      <h5 className="font-mono text-xs text-white/50">{exp.company}</h5>
                      <p className="text-white/60 text-xs font-light leading-relaxed mt-3">{exp.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. CERTIFICATE GRID */}
      <section id="certificates-grid" className="py-24 bg-[#0A0A0A] relative z-10 border-t border-white/5 grid-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center lg:text-left mb-16">
            <h3 className="font-mono text-xs text-[#FF3333] uppercase tracking-widest font-bold mb-2">05 // VERIFIED ARCHIVES</h3>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white">
              {lang === 'en' ? 'Certifications & Accreditation' : 'Sertifikasi & Lisensi'}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certificates.map((cert) => (
              <div key={cert.id} className="bg-[#0D0D0D] border border-white/5 hover:border-[#FF3333]/20 rounded-xl p-5 flex flex-col justify-between group transition-all duration-300">
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="p-2.5 bg-[#FF3333]/10 border border-[#FF3333]/15 rounded-lg text-[#FF3333]">
                      <Award className="w-5 h-5" />
                    </div>
                    <span className="font-mono text-[10px] text-white/40">{cert.issueDate}</span>
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-white text-sm leading-snug group-hover:text-[#FF3333] transition-colors">{cert.name}</h4>
                    <p className="text-white/40 text-xs font-mono mt-1">{cert.issuer}</p>
                  </div>
                </div>
                {cert.credentialUrl && (
                  <div className="mt-5 pt-3 border-t border-white/5">
                    <a 
                      href={cert.credentialUrl} 
                      target="_blank" 
                      rel="noreferrer" 
                      className="text-[10px] font-mono text-white/50 hover:text-[#FF3333] flex items-center space-x-1"
                    >
                      <span>Verify Credential</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. ART GALLERY */}
      <section id="portfolio-gallery" className="py-24 relative z-10 border-t border-white/5 grid-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center lg:text-left mb-16">
            <h3 className="font-mono text-xs text-[#FF3333] uppercase tracking-widest font-bold mb-2">06 // CREATIVE SPACE</h3>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white">
              {lang === 'en' ? 'Art & UI Explorations' : 'Galeri Seni & Eksplorasi UI'}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {gallery.map((item) => (
              <div key={item.id} className="bg-[#0D0D0D] border border-white/5 hover:border-[#FF3333]/20 rounded-xl overflow-hidden shadow-xl group">
                <div className="aspect-video w-full bg-[#0A0A0A] relative overflow-hidden flex items-center justify-center border-b border-white/5">
                  <div className="absolute inset-0 grid-bg opacity-10" />
                  {item.image ? (
                    <img src={item.image} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  ) : (
                    <div className="flex flex-col items-center justify-center p-6 text-center text-white/30">
                      <ImageIcon className="w-12 h-12 text-white/20 mb-1.5" />
                      <span className="font-mono text-[9px] uppercase tracking-widest">ART_ASSET_MODULE</span>
                    </div>
                  )}
                  <div className="absolute bottom-3 left-3 bg-black/70 border border-white/5 backdrop-blur-md px-2.5 py-1 rounded font-mono text-[9px] text-white/80 tracking-wider">
                    {item.category}
                  </div>
                </div>
                <div className="p-5">
                  <h4 className="font-display font-bold text-white text-base">{item.title}</h4>
                  <p className="text-white/60 text-xs font-light mt-1.5">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. SECURE CONTACT FORM */}
      <section id="contact-hub" className="py-24 sm:py-32 bg-[#0A0A0A] relative z-10 border-t border-white/5 grid-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center lg:text-left mb-16">
            <h3 className="font-mono text-xs text-[#FF3333] uppercase tracking-widest font-bold mb-2">07 // COMMS PROTOCOL</h3>
            <h2 className="font-display font-extrabold text-3xl sm:text-5xl text-white">
              {lang === 'en' ? 'Connect Encrypted Node' : 'Hubungi Node Terenkripsi'}
            </h2>
          </div>

          <ContactForm lang={lang} onNewMessageSent={onNewMessageSent} />
        </div>
      </section>

      {/* FOOTER SPECS */}
      <footer className="py-8 bg-[#0A0A0A] border-t border-white/5 text-center text-xs text-white/40 relative z-10 font-mono tracking-wider">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>© 2026 Ahmad Yusuf Syarifullah. All rights reserved.</p>
          <div className="flex space-x-6">
            <button onClick={() => onNavigateTab('privacy')} className="hover:text-[#FF3333] cursor-pointer">Privacy Policy</button>
            <button onClick={() => onNavigateTab('terms')} className="hover:text-[#FF3333] cursor-pointer">Terms of Service</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
