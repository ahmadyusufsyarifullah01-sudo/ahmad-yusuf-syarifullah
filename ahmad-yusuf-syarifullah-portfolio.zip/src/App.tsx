import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, LogIn, Lock, Mail, ChevronRight, X, AlertCircle, Loader2 
} from 'lucide-react';

import Preloader from './components/Preloader';
import ParticleBackground from './components/ParticleBackground';
import Navbar from './components/Navbar';
import PortfolioView from './pages/PortfolioView';
import ProductivityDashboard from './pages/ProductivityDashboard';
import AdminPanel from './components/AdminPanel';

import { Profile, NotificationItem } from './types';

export default function App() {
  const [preloaderComplete, setPreloaderComplete] = useState(false);
  const [activeTab, setActiveTab] = useState('portfolio'); // portfolio, dashboard, blogs, gallery, admin, privacy, terms
  const [lang, setLang] = useState<'en' | 'id'>('en');

  // Database models
  const [profile, setProfile] = useState<Profile | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Authentication State
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  // Fetch baseline layout stats
  const fetchBaseData = async () => {
    try {
      const pRes = await fetch('/api/profile');
      if (pRes.ok) {
        setProfile(await pRes.json());
      }
    } catch (e) {
      console.error('Error fetching baseline details:', e);
    }
  };

  const fetchNotifications = async () => {
    const token = localStorage.getItem('portfolio_admin_token');
    if (!token) return;
    try {
      const res = await fetch('/api/notifications', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setNotifications(await res.json());
      }
    } catch (e) {
      console.error('Error fetching notifications:', e);
    }
  };

  // Check login session longevity on load
  const checkSession = async () => {
    const token = localStorage.getItem('portfolio_admin_token');
    if (!token) return;

    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setIsAdmin(true);
        fetchNotifications();
      } else {
        localStorage.removeItem('portfolio_admin_token');
        setIsAdmin(false);
      }
    } catch (e) {
      localStorage.removeItem('portfolio_admin_token');
      setIsAdmin(false);
    }
  };

  useEffect(() => {
    fetchBaseData();
    checkSession();
  }, []);

  // Poll for notifications periodically if admin is logged in
  useEffect(() => {
    if (!isAdmin) return;
    const interval = setInterval(fetchNotifications, 10000);
    return () => clearInterval(interval);
  }, [isAdmin]);

  // Handle Mark Notifications Read
  const handleMarkAllRead = async () => {
    const token = localStorage.getItem('portfolio_admin_token');
    if (!token) return;

    try {
      const res = await fetch('/api/notifications/mark-all-read', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        fetchNotifications();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Submit Administrative credentials
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: usernameInput, password: passwordInput })
      });

      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('portfolio_admin_token', data.token);
        setIsAdmin(true);
        setShowLoginModal(false);
        setUsernameInput('');
        setPasswordInput('');
        setActiveTab('admin'); // auto jump to panel
        fetchNotifications();
      } else {
        throw new Error(data.error || 'Login failure');
      }
    } catch (err: any) {
      setAuthError(err.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('portfolio_admin_token');
    setIsAdmin(false);
    setActiveTab('portfolio');
  };

  // Default fallbacks while database profile loads on cold container boots
  const currentProfile: Profile = profile || {
    id: 'p-1',
    name: 'Ahmad Yusuf Syarifullah',
    title: 'Enterprise Full Stack Developer & UI/UX Designer',
    subtitles: ['Full Stack Developer', 'UI/UX Engineer', 'DevOps & Cloud Specialist'],
    bio: 'Crafting beautiful, high-performance, and secure web applications with standard enterprise-grade architectures.',
    avatar: ''
  };

  return (
    <div className="relative min-h-screen bg-[#09090b] text-zinc-100 selection:bg-red-500 selection:text-white">
      
      {/* 1. INITIAL CINEMATIC PRELOADER */}
      <Preloader onComplete={() => setPreloaderComplete(true)} />

      {preloaderComplete && (
        <div className="fade-in-content">
          
          {/* INTERACTIVE BACKGROUND GLOBES */}
          <ParticleBackground />

          {/* 2. HEADER NAVIGATION */}
          <Navbar 
            activeTab={activeTab} 
            setActiveTab={(tab) => {
              setActiveTab(tab);
              // Scroll page to top on tab transitions
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
            setLang={setLang}
            isAdmin={isAdmin}
            onLoginClick={() => setShowLoginModal(true)}
            onLogout={handleLogout}
            notifications={notifications}
            onMarkAllRead={handleMarkAllRead}
          />

          {/* 3. PRIMARY CONTENT SECTIONS */}
          <main className="relative z-10">
            <AnimatePresence mode="wait">
              
              {activeTab === 'portfolio' && (
                <motion.div
                  key="portfolio"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.4 }}
                >
                  <PortfolioView 
                    profile={currentProfile} 
                    lang={lang} 
                    onNewMessageSent={fetchNotifications}
                    onNavigateTab={(tab) => {
                      setActiveTab(tab);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                </motion.div>
              )}

              {activeTab === 'privacy' && (
                <motion.div
                  key="privacy"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="py-32 max-w-4xl mx-auto px-4 space-y-8 min-h-[80vh]"
                >
                  <div className="space-y-2">
                    <span className="font-mono text-xs text-red-500 uppercase tracking-widest font-semibold">SECURITY PROTOCOL & DATA DIRECTIVES</span>
                    <h1 className="font-display font-extrabold text-4xl text-white">Privacy Policy</h1>
                    <p className="text-zinc-500 font-mono text-xs">Last updated: July 15, 2026</p>
                  </div>
                  <div className="glass-card border border-zinc-900 rounded-xl p-6 sm:p-8 space-y-6 text-zinc-300 font-sans text-sm leading-relaxed">
                    <p>
                      Welcome to the personal professional workspace of Ahmad Yusuf Syarifullah. Your privacy is paramount. This directive outlines our strict protocols regarding the ingestion, storage, and processing of user data telemetry.
                    </p>
                    <h2 className="text-white font-display font-bold text-lg mt-6">1. Telemetry Ingestion</h2>
                    <p>
                      We ingest data voluntarily provided via our secure communications tunnel (Contact Form). This includes names, emails, and custom text payloads. This data is handled in an isolated, encrypted persistent database layer strictly within our sandbox container environment.
                    </p>
                    <h2 className="text-white font-display font-bold text-lg mt-6">2. Cookies and Preferences</h2>
                    <p>
                      This site utilizes client-side storage mechanisms (localStorage) exclusively to sustain administrative authentication sessions and locally selected preferences (language toggles, offline tasks logs). No persistent tracking identifiers or third-party cookies are distributed.
                    </p>
                    <button 
                      onClick={() => { setActiveTab('portfolio'); window.scrollTo({ top: 0 }); }}
                      className="px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-850 font-mono text-xs tracking-wider uppercase rounded-lg"
                    >
                      Return to Portfolio
                    </button>
                  </div>
                </motion.div>
              )}

              {activeTab === 'terms' && (
                <motion.div
                  key="terms"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="py-32 max-w-4xl mx-auto px-4 space-y-8 min-h-[80vh]"
                >
                  <div className="space-y-2">
                    <span className="font-mono text-xs text-red-500 uppercase tracking-widest font-semibold">LEGAL COMPLIANCE FRAMEWORK</span>
                    <h1 className="font-display font-extrabold text-4xl text-white">Terms of Service</h1>
                    <p className="text-zinc-500 font-mono text-xs">Last updated: July 15, 2026</p>
                  </div>
                  <div className="glass-card border border-zinc-900 rounded-xl p-6 sm:p-8 space-y-6 text-zinc-300 font-sans text-sm leading-relaxed">
                    <p>
                      These Terms govern the usage of the enterprise-grade portfolio and productivity portal of Ahmad Yusuf Syarifullah. By accessing this service, you consent to compile and execute under these provisions.
                    </p>
                    <h2 className="text-white font-display font-bold text-lg mt-6">1. Permitted Execution</h2>
                    <p>
                      This application, including all mock metrics, productivity telemetry trackers, source assets, and database backup structures, is distributed as a display of architectural expertise. Reverse engineering, security audits, and general exploration are welcome.
                    </p>
                    <h2 className="text-white font-display font-bold text-lg mt-6">2. Limitation of Telemetry Liability</h2>
                    <p>
                      All database states, tasks records, and logs are self-contained within this runtime instance. We offer no guarantees regarding data longevity in the event of major database restores or server cluster migrations.
                    </p>
                    <button 
                      onClick={() => { setActiveTab('portfolio'); window.scrollTo({ top: 0 }); }}
                      className="px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-850 font-mono text-xs tracking-wider uppercase rounded-lg"
                    >
                      Return to Portfolio
                    </button>
                  </div>
                </motion.div>
              )}

              {activeTab === 'dashboard' && (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.4 }}
                >
                  <ProductivityDashboard 
                    lang={lang} 
                    isAdmin={isAdmin}
                    onLoginClick={() => setShowLoginModal(true)}
                  />
                </motion.div>
              )}

              {activeTab === 'admin' && isAdmin && (
                <motion.div
                  key="admin"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.4 }}
                >
                  <AdminPanel lang={lang} onLogout={handleLogout} />
                </motion.div>
              )}

              {/* Insights and Blog lists shortcut redirecting back onto portfolio items */}
              {(activeTab === 'blogs' || activeTab === 'gallery') && (
                <motion.div
                  key="redirect"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="py-32 flex flex-col items-center justify-center min-h-[60vh] max-w-lg mx-auto text-center space-y-6 px-4"
                >
                  <h2 className="font-display font-extrabold text-2xl text-white uppercase tracking-wider glow-text-red">Section Redirect</h2>
                  <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                    {lang === 'en' 
                      ? 'The complete list is fully integrated within our main portfolio workspace timeline for quick cross-referencing. Click the button below to jump directly onto it.'
                      : 'Kumpulan data terintegrasi secara dinamis dalam lini masa portofolio utama kami. Klik tombol di bawah ini untuk melihat langsung.'}
                  </p>
                  <button 
                    onClick={() => {
                      setActiveTab('portfolio');
                      setTimeout(() => {
                        const target = activeTab === 'blogs' ? 'certificates-grid' : 'portfolio-gallery';
                        document.getElementById(target)?.scrollIntoView({ behavior: 'smooth' });
                      }, 200);
                    }}
                    className="px-6 py-3 bg-red-600 hover:bg-red-500 font-mono text-xs font-bold uppercase tracking-widest text-white rounded-lg shadow-lg cursor-pointer"
                  >
                    {lang === 'en' ? 'Open Portfolio Section' : 'Buka Bagian Portofolio'}
                  </button>
                </motion.div>
              )}

            </AnimatePresence>
          </main>

          {/* 4. ADMIN AUTHENTICATION DIALOG MODAL */}
          <AnimatePresence>
            {showLoginModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                
                {/* Backdrop shade */}
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setShowLoginModal(false)}
                  className="absolute inset-0 bg-black/80 backdrop-blur-md"
                />

                {/* Form dialog card */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="glass-card border border-zinc-800 rounded-2xl p-6 sm:p-8 max-w-md w-full relative z-10 shadow-2xl space-y-6"
                >
                  <div className="flex justify-between items-center pb-2 border-b border-zinc-900">
                    <div className="flex items-center space-x-2 text-red-500 font-mono text-[11px] font-bold tracking-wider uppercase">
                      <Lock className="w-4 h-4" />
                      <span>Security Gateway</span>
                    </div>
                    <button 
                      onClick={() => setShowLoginModal(false)}
                      className="p-1 border border-zinc-900 rounded text-zinc-500 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="text-center space-y-1.5">
                    <h3 className="font-display font-extrabold text-2xl text-white">Admin Credentials</h3>
                    <p className="text-zinc-500 text-xs font-sans leading-normal">
                      {lang === 'en' 
                        ? 'Sign in with your enterprise credentials. Defaults to: admin // password'
                        : 'Masuk dengan kredensial sistem Anda. Bawaan: admin // password'}
                    </p>
                  </div>

                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-mono text-zinc-400 uppercase tracking-widest font-bold" htmlFor="login-username">
                        Username
                      </label>
                      <input
                        id="login-username"
                        type="text"
                        required
                        value={usernameInput}
                        onChange={e => setUsernameInput(e.target.value)}
                        placeholder="admin"
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-700 focus:outline-none focus:border-red-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-mono text-zinc-400 uppercase tracking-widest font-bold" htmlFor="login-password">
                        Secret Password
                      </label>
                      <input
                        id="login-password"
                        type="password"
                        required
                        value={passwordInput}
                        onChange={e => setPasswordInput(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2.5 text-xs text-zinc-200 placeholder-zinc-700 focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {authError && (
                      <div className="p-3 bg-red-950/20 border border-red-500/20 text-red-400 text-xs rounded-lg flex items-start space-x-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                        <span>{authError}</span>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={authLoading}
                      className="w-full py-3.5 bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold tracking-widest uppercase rounded-lg flex items-center justify-center space-x-2 cursor-pointer shadow-[0_0_12px_rgba(239,68,68,0.2)]"
                    >
                      {authLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin text-white" />
                          <span>Verifying Identity...</span>
                        </>
                      ) : (
                        <>
                          <LogIn className="w-4 h-4" />
                          <span>Unlock Command Center</span>
                        </>
                      )}
                    </button>
                  </form>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

        </div>
      )}
    </div>
  );
}
