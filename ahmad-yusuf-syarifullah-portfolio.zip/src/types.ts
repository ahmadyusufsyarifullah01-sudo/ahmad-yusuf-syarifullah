export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
  passwordHash: string;
  createdAt: string;
}

export interface Profile {
  id: string;
  name: string;
  title: string;
  subtitles: string[]; // for typewriter
  bio: string;
  avatar: string; // url or base64
  cvUrl?: string;
  location?: string;
  email?: string;
  phone?: string;
  github?: string;
  linkedin?: string;
  instagram?: string;
}

export interface Skill {
  id: string;
  name: string;
  category: 'Frontend' | 'Backend' | 'Database' | 'DevOps' | 'Tools';
  level: number; // 0-100
  icon: string; // Lucide icon name or base64
}

export interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  image: string;
  githubUrl?: string;
  demoUrl?: string;
  featured: boolean;
  order: number;
}

export interface Certificate {
  id: string;
  name: string;
  issuer: string;
  issueDate: string;
  credentialUrl?: string;
  image: string;
}

export interface Blog {
  id: string;
  title: string;
  slug: string;
  content: string;
  image: string;
  category: string;
  tags: string[];
  status: 'draft' | 'published';
  views: number;
  createdAt: string;
  updatedAt: string;
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string; // or 'Present'
  description: string;
  current: boolean;
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  gpa?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject?: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface SocialLink {
  id: string;
  platform: string;
  url: string;
  icon: string;
}

export interface Setting {
  id: string;
  key: string;
  value: string;
}

export interface Activity {
  id: string;
  type: 'system' | 'auth' | 'crud' | 'message';
  description: string;
  details?: string;
  username?: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface Task {
  id: string;
  title: string;
  status: 'todo' | 'in_progress' | 'done';
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  createdAt: string;
}

export interface LearningLog {
  id: string;
  topic: string;
  hours: number;
  date: string;
}

export interface DashboardStats {
  learningHoursThisWeek: number;
  githubCommitsThisMonth: number;
  completedTasks: number;
  pendingTasks: number;
  messagesCount: number;
  unreadMessagesCount: number;
  skillsCount: number;
  projectsCount: number;
  blogsCount: number;
  blogViewsCount: number;
}
