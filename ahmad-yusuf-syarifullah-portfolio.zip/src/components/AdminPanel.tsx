import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Profile, Skill, Project, Certificate, Blog, 
  Experience, Education, GalleryItem, ContactMessage, 
  SocialLink, Setting, Activity, Task, LearningLog
} from '../types';
import { 
  Plus, Edit2, Trash2, Shield, Settings, FileText, Database, 
  MessageSquare, Layers, Award, Clock, Link, Check, X, LogOut, 
  ChevronRight, Upload, Download, Sparkles, UserCheck, Terminal
} from 'lucide-react';

interface AdminPanelProps {
  lang: 'en' | 'id';
  onLogout: () => void;
}

export default function AdminPanel({ lang, onLogout }: AdminPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'projects' | 'skills' | 'certificates' | 'blogs' | 'gallery' | 'experience' | 'education' | 'contacts' | 'settings' | 'backup'>('profile');
  
  // Database data states
  const [profile, setProfile] = useState<Profile | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [experiences, setExperiences] = useState<Experience[]>([]);
  const [education, setEducation] = useState<Education[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [settings, setSettings] = useState<Setting[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);

  // Editing form states & modals
  const [isEditing, setIsEditing] = useState<string | null>(null); // holds id of item being edited, or 'new'
  const [formData, setFormData] = useState<any>({});
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Fetch admin-only lists
  const fetchAdminData = async () => {
    const token = localStorage.getItem('portfolio_admin_token');
    if (!token) return;

    try {
      const headers = { 'Authorization': `Bearer ${token}` };
      
      const [profRes, projRes, skillRes, certRes, blogRes, galRes, expRes, eduRes, msgRes, setRes, actRes] = await Promise.all([
        fetch('/api/profile'),
        fetch('/api/projects'),
        fetch('/api/skills'),
        fetch('/api/certificates'),
        fetch('/api/blogs'),
        fetch('/api/gallery'),
        fetch('/api/experiences'),
        fetch('/api/education'),
        fetch('/api/contacts', { headers }),
        fetch('/api/settings'),
        fetch('/api/activities', { headers })
      ]);

      if (profRes.ok) setProfile(await profRes.json());
      if (projRes.ok) setProjects(await projRes.json());
      if (skillRes.ok) setSkills(await skillRes.json());
      if (certRes.ok) setCertificates(await certRes.json());
      if (blogRes.ok) setBlogs(await blogRes.json());
      if (galRes.ok) setGallery(await galRes.json());
      if (expRes.ok) setExperiences(await expRes.json());
      if (eduRes.ok) setEducation(await eduRes.json());
      if (msgRes.ok) setMessages(await msgRes.json());
      if (setRes.ok) setSettings(await setRes.json());
      if (actRes.ok) setActivities(await actRes.json());

    } catch (err) {
      console.error('Error loading admin lists:', err);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [activeSubTab]);

  const handleOpenForm = (id: string | null, defaults: any = {}) => {
    setIsEditing(id || 'new');
    setFormData(defaults);
    setErrorMsg('');
    setSuccessMsg('');
  };

  const handleCloseForm = () => {
    setIsEditing(null);
    setFormData({});
  };

  // Generic Submit handler for all CRUD tables
  const handleCrudSubmit = async (e: React.FormEvent, endpoint: string, method: 'POST' | 'PUT') => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const token = localStorage.getItem('portfolio_admin_token');
    const url = method === 'PUT' ? `${endpoint}/${formData.id}` : endpoint;

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });

      const result = await res.json();
      if (res.ok) {
        setSuccessMsg(lang === 'en' ? 'Database record synchronized successfully!' : 'Rekor database berhasil disinkronkan!');
        fetchAdminData();
        setTimeout(() => handleCloseForm(), 800);
      } else {
        throw new Error(result.error || 'Sync failure');
      }
    } catch (err: any) {
      setErrorMsg(err.message);
    }
  };

  // Delete handler with strict browser confirmation as required
  const handleCrudDelete = async (endpoint: string, id: string) => {
    const confirmDelete = window.confirm(lang === 'en' ? 'CRITICAL: Are you sure you want to delete this database entry?' : 'PENTING: Apakah Anda yakin ingin menghapus rekor database ini?');
    if (!confirmDelete) return;

    const token = localStorage.getItem('portfolio_admin_token');
    try {
      const res = await fetch(`${endpoint}/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (res.ok) {
        fetchAdminData();
      } else {
        const err = await res.json();
        alert(`Delete error: ${err.error}`);
      }
    } catch (e: any) {
      alert(`Delete failed: ${e.message}`);
    }
  };

  // Inbox management
  const handleMarkMessageRead = async (id: string) => {
    const token = localStorage.getItem('portfolio_admin_token');
    try {
      const res = await fetch(`/api/contacts/${id}/read`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) fetchAdminData();
    } catch (e) {
      console.error(e);
    }
  };

  // Backup file export downloads the database JSON directly to client!
  const handleBackupExport = () => {
    const token = localStorage.getItem('portfolio_admin_token');
    if (!token) return;
    window.open(`/api/backup?token=${token}`, '_blank');
  };

  // Restore database JSON upload
  const handleBackupRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        const token = localStorage.getItem('portfolio_admin_token');
        const res = await fetch('/api/backup/restore', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(json)
        });

        const result = await res.json();
        if (res.ok) {
          alert(lang === 'en' ? 'Database restored successfully!' : 'Database berhasil dipulihkan!');
          fetchAdminData();
        } else {
          throw new Error(result.error);
        }
      } catch (err: any) {
        alert(`Restore failed: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  return (
    <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid-bg min-h-screen relative z-10">
      
      {/* Admin Title Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center pb-8 border-b border-zinc-900 mb-10 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-red-500 font-mono text-xs tracking-widest font-bold uppercase">
            <Shield className="w-4 h-4" />
            <span>SECURE CONTROL DEPLOYMENT ENVIRONMENT</span>
          </div>
          <h1 className="font-display font-extrabold text-3xl sm:text-5xl text-white mt-1">
            {lang === 'en' ? 'Admin Panel' : 'Panel Dashboard Admin'}
          </h1>
        </div>
        <button 
          onClick={onLogout}
          className="px-4 py-2 border border-zinc-800 hover:border-red-500/20 text-zinc-400 hover:text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1.5 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Logout</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* SIDEBAR NAVIGATION (lg:col-span-3) */}
        <div className="lg:col-span-3 glass-card border border-zinc-900 rounded-xl p-3 space-y-1">
          {[
            { id: 'profile', label: 'Kelola Profile', icon: UserCheck },
            { id: 'projects', label: 'Kelola Projects', icon: Layers },
            { id: 'skills', label: 'Kelola Skills', icon: Sparkles },
            { id: 'certificates', label: 'Kelola Certificates', icon: Award },
            { id: 'blogs', label: 'Kelola Blogs', icon: FileText },
            { id: 'gallery', label: 'Kelola Gallery', icon: Database },
            { id: 'experience', label: 'Kelola Timeline', icon: Clock },
            { id: 'contacts', label: `Kelola Messages (${messages.filter(m => !m.isRead).length})`, icon: MessageSquare },
            { id: 'backup', label: 'Kelola Backup', icon: Database }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => { setActiveSubTab(tab.id as any); handleCloseForm(); }}
                className={`w-full px-4 py-3 text-left rounded-lg text-xs font-mono tracking-wider uppercase flex items-center justify-between transition-colors ${
                  activeSubTab === tab.id 
                    ? 'bg-red-600 text-white shadow-[0_0_10px_rgba(239,68,68,0.25)]' 
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/40'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </div>
                <ChevronRight className="w-3 h-3 opacity-60" />
              </button>
            );
          })}
        </div>

        {/* DATA CONTAINER WORKSPACE (lg:col-span-9) */}
        <div className="lg:col-span-9 glass-card border border-zinc-900 rounded-xl p-6 sm:p-8 min-h-[500px] relative">
          
          <AnimatePresence mode="wait">
            
            {/* --- CORE FORM OVERLAYS --- */}
            {isEditing && (
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 15 }}
                className="absolute inset-0 bg-zinc-950/95 backdrop-blur-md rounded-xl p-6 sm:p-8 z-30 overflow-y-auto"
              >
                <div className="flex justify-between items-center pb-4 border-b border-zinc-900 mb-6">
                  <h3 className="font-display font-bold text-lg text-white">
                    {isEditing === 'new' ? 'Create New Database Record' : 'Edit Existing Database Record'}
                  </h3>
                  <button onClick={handleCloseForm} className="p-1 border border-zinc-800 rounded text-zinc-500 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form 
                  onSubmit={(e) => {
                    const endpoint = `/api/${activeSubTab === 'experience' ? 'experiences' : activeSubTab}`;
                    handleCrudSubmit(e, endpoint, isEditing === 'new' ? 'POST' : 'PUT');
                  }}
                  className="space-y-4"
                >
                  {/* --- DYNAMIC FORM FIELDS --- */}
                  
                  {/* Profile Form */}
                  {activeSubTab === 'profile' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Full Name</label>
                        <input type="text" required value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Display Title</label>
                        <input type="text" required value={formData.title || ''} onChange={e => setFormData({ ...formData, title: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1 sm:col-span-2">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Bio Details</label>
                        <textarea rows={4} required value={formData.bio || ''} onChange={e => setFormData({ ...formData, bio: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 resize-none" />
                      </div>
                    </div>
                  )}

                  {/* Skills Form */}
                  {activeSubTab === 'skills' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Skill Name</label>
                        <input type="text" required value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Category</label>
                        <select required value={formData.category || 'Frontend'} onChange={e => setFormData({ ...formData, category: e.target.value as any })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-400 font-mono">
                          <option value="Frontend">Frontend</option>
                          <option value="Backend">Backend</option>
                          <option value="Database">Database</option>
                          <option value="DevOps">DevOps</option>
                          <option value="Tools">Tools</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Progress (0-100)</label>
                        <input type="number" required min={0} max={100} value={formData.level || 0} onChange={e => setFormData({ ...formData, level: Number(e.target.value) })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                    </div>
                  )}

                  {/* Projects Form */}
                  {activeSubTab === 'projects' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Project Title</label>
                        <input type="text" required value={formData.title || ''} onChange={e => setFormData({ ...formData, title: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Category</label>
                        <input type="text" required value={formData.category || ''} onChange={e => setFormData({ ...formData, category: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" placeholder="e.g. Full-Stack Web App" />
                      </div>
                      <div className="space-y-1 sm:col-span-2">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Description</label>
                        <textarea required value={formData.description || ''} onChange={e => setFormData({ ...formData, description: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 resize-none" rows={3} />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">GitHub Url</label>
                        <input type="text" value={formData.githubUrl || ''} onChange={e => setFormData({ ...formData, githubUrl: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Demo Live Url</label>
                        <input type="text" value={formData.demoUrl || ''} onChange={e => setFormData({ ...formData, demoUrl: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Tags (Comma Separated)</label>
                        <input type="text" required value={formData.tags ? formData.tags.join(', ') : ''} onChange={e => setFormData({ ...formData, tags: e.target.value.split(',').map(x => x.trim()) })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" placeholder="React, Node, etc" />
                      </div>
                      <div className="space-y-1 flex items-center space-x-3 pt-6">
                        <input type="checkbox" checked={formData.featured || false} onChange={e => setFormData({ ...formData, featured: e.target.checked })} className="w-4 h-4 rounded text-red-500 bg-zinc-900 border-zinc-800" />
                        <label className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest font-bold">Featured Highlight</label>
                      </div>
                    </div>
                  )}

                  {/* Certificates Form */}
                  {activeSubTab === 'certificates' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Accreditation Name</label>
                        <input type="text" required value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Issuer Institution</label>
                        <input type="text" required value={formData.issuer || ''} onChange={e => setFormData({ ...formData, issuer: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Issue Date</label>
                        <input type="date" required value={formData.issueDate || ''} onChange={e => setFormData({ ...formData, issueDate: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Verify Credential URL</label>
                        <input type="text" value={formData.credentialUrl || ''} onChange={e => setFormData({ ...formData, credentialUrl: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                    </div>
                  )}

                  {/* Blog Form */}
                  {activeSubTab === 'blogs' && (
                    <div className="grid grid-cols-1 gap-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Blog Title</label>
                          <input type="text" required value={formData.title || ''} onChange={e => setFormData({ ...formData, title: e.target.value, slug: e.target.value.toLowerCase().replace(/ /g, '-') })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">URL Slug</label>
                          <input type="text" required value={formData.slug || ''} onChange={e => setFormData({ ...formData, slug: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 font-mono" />
                        </div>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Markdown Content Body</label>
                        <textarea required value={formData.content || ''} onChange={e => setFormData({ ...formData, content: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 font-mono resize-none" rows={12} />
                      </div>
                    </div>
                  )}

                  {/* Experience Timeline Form */}
                  {activeSubTab === 'experience' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Role / Title</label>
                        <input type="text" required value={formData.role || ''} onChange={e => setFormData({ ...formData, role: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Company</label>
                        <input type="text" required value={formData.company || ''} onChange={e => setFormData({ ...formData, company: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Start Date</label>
                        <input type="date" required value={formData.startDate || ''} onChange={e => setFormData({ ...formData, startDate: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">End Date</label>
                        <input type="text" required value={formData.endDate || ''} onChange={e => setFormData({ ...formData, endDate: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200" placeholder="e.g. 2026-07-01 or Present" />
                      </div>
                      <div className="space-y-1 sm:col-span-2">
                        <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-bold">Work Description</label>
                        <textarea required value={formData.description || ''} onChange={e => setFormData({ ...formData, description: e.target.value })} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-200 resize-none" rows={3} />
                      </div>
                    </div>
                  )}

                  {/* Feedback signals */}
                  {errorMsg && <p className="text-xs text-red-500 font-mono">ERROR: {errorMsg}</p>}
                  {successMsg && <p className="text-xs text-emerald-500 font-mono">SUCCESS: {successMsg}</p>}

                  {/* Submit actions */}
                  <div className="flex justify-end space-x-3 pt-4 border-t border-zinc-900">
                    <button type="button" onClick={handleCloseForm} className="px-4 py-2 border border-zinc-800 text-zinc-400 hover:text-white rounded text-xs font-mono uppercase">
                      Cancel
                    </button>
                    <button type="submit" className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-mono uppercase shadow-[0_0_10px_rgba(239,68,68,0.3)]">
                      Synchronize
                    </button>
                  </div>
                </form>
              </motion.div>
            )}

            {/* --- WORKSPACE VIEWS --- */}
            
            {/* 1. Profile View */}
            {activeSubTab === 'profile' && profile && (
              <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="font-display font-extrabold text-xl text-white">Identity Configuration</h2>
                  <button onClick={() => handleOpenForm(profile.id, profile)} className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1 cursor-pointer">
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Edit Profile</span>
                  </button>
                </div>
                <div className="border border-zinc-900 bg-zinc-900/10 p-5 rounded-xl space-y-3 font-mono text-xs text-zinc-400">
                  <p><strong className="text-white">Name:</strong> {profile.name}</p>
                  <p><strong className="text-white">Title:</strong> {profile.title}</p>
                  <p><strong className="text-white">Bio:</strong> <span className="font-sans font-light leading-relaxed">{profile.bio}</span></p>
                  <p><strong className="text-white">HQ Coordinates:</strong> Yogyakarta, Indonesia</p>
                </div>
              </motion.div>
            )}

            {/* 2. Projects CRUD List */}
            {activeSubTab === 'projects' && (
              <motion.div key="projects" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="font-display font-extrabold text-xl text-white">Projects Registry</h2>
                  <button onClick={() => handleOpenForm(null, { featured: false, tags: [], order: 1 })} className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1 cursor-pointer">
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Project</span>
                  </button>
                </div>
                <div className="space-y-2.5">
                  {projects.map((proj) => (
                    <div key={proj.id} className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-xl flex justify-between items-center">
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">{proj.title}</h4>
                        <span className="font-mono text-[9px] text-zinc-500 uppercase">{proj.category}</span>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => handleOpenForm(proj.id, proj)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-white rounded hover:bg-zinc-900" title="Edit">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleCrudDelete('/api/projects', proj.id)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-red-500 rounded hover:bg-red-950/10" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 3. Skills CRUD List */}
            {activeSubTab === 'skills' && (
              <motion.div key="skills" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="font-display font-extrabold text-xl text-white">Skills Matrix</h2>
                  <button onClick={() => handleOpenForm(null, { level: 80, category: 'Frontend' })} className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1 cursor-pointer">
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Skill</span>
                  </button>
                </div>
                <div className="space-y-2.5">
                  {skills.map((skill) => (
                    <div key={skill.id} className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-xl flex justify-between items-center">
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">{skill.name}</h4>
                        <span className="font-mono text-[9px] text-red-500/80 uppercase font-semibold">{skill.category} ({skill.level}%)</span>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => handleOpenForm(skill.id, skill)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-white rounded hover:bg-zinc-900" title="Edit">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleCrudDelete('/api/skills', skill.id)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-red-500 rounded hover:bg-red-950/10" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 4. Certificates CRUD List */}
            {activeSubTab === 'certificates' && (
              <motion.div key="certificates" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="font-display font-extrabold text-xl text-white">Certificates Ledger</h2>
                  <button onClick={() => handleOpenForm(null, { issueDate: new Date().toISOString().split('T')[0] })} className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1 cursor-pointer">
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Certificate</span>
                  </button>
                </div>
                <div className="space-y-2.5">
                  {certificates.map((cert) => (
                    <div key={cert.id} className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-xl flex justify-between items-center">
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">{cert.name}</h4>
                        <span className="font-mono text-[9px] text-zinc-500 uppercase">{cert.issuer}</span>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => handleOpenForm(cert.id, cert)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-white rounded hover:bg-zinc-900" title="Edit">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleCrudDelete('/api/certificates', cert.id)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-red-500 rounded hover:bg-red-950/10" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 5. Blogs CRUD List */}
            {activeSubTab === 'blogs' && (
              <motion.div key="blogs" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="font-display font-extrabold text-xl text-white">Insights & Blogs</h2>
                  <button onClick={() => handleOpenForm(null, { status: 'published', tags: [], views: 0 })} className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1 cursor-pointer">
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Blog Post</span>
                  </button>
                </div>
                <div className="space-y-2.5">
                  {blogs.map((blog) => (
                    <div key={blog.id} className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-xl flex justify-between items-center">
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">{blog.title}</h4>
                        <span className="font-mono text-[9px] text-zinc-500 uppercase">{blog.slug}</span>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => handleOpenForm(blog.id, blog)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-white rounded hover:bg-zinc-900" title="Edit">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleCrudDelete('/api/blogs', blog.id)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-red-500 rounded hover:bg-red-950/10" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 6. Timeline CRUD List */}
            {activeSubTab === 'experience' && (
              <motion.div key="experience" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="font-display font-extrabold text-xl text-white">Timeline Milestone</h2>
                  <button onClick={() => handleOpenForm(null, { startDate: new Date().toISOString().split('T')[0], endDate: 'Present', current: true })} className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1 cursor-pointer">
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Milestone</span>
                  </button>
                </div>
                <div className="space-y-2.5">
                  {experiences.map((exp) => (
                    <div key={exp.id} className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-xl flex justify-between items-center">
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">{exp.role}</h4>
                        <span className="font-mono text-[9px] text-zinc-500 uppercase">{exp.company}</span>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => handleOpenForm(exp.id, exp)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-white rounded hover:bg-zinc-900" title="Edit">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleCrudDelete('/api/experiences', exp.id)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-red-500 rounded hover:bg-red-950/10" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 7. Gallery CRUD List */}
            {activeSubTab === 'gallery' && (
              <motion.div key="gallery" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="font-display font-extrabold text-xl text-white">Art Gallery</h2>
                  <button onClick={() => handleOpenForm(null, {})} className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-mono tracking-wider uppercase flex items-center space-x-1 cursor-pointer">
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Image Asset</span>
                  </button>
                </div>
                <div className="space-y-2.5">
                  {gallery.map((item) => (
                    <div key={item.id} className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-xl flex justify-between items-center">
                      <div>
                        <h4 className="font-display font-bold text-white text-sm">{item.title}</h4>
                        <span className="font-mono text-[9px] text-zinc-500 uppercase">{item.category}</span>
                      </div>
                      <div className="flex space-x-2">
                        <button onClick={() => handleOpenForm(item.id, item)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-white rounded hover:bg-zinc-900" title="Edit">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleCrudDelete('/api/gallery', item.id)} className="p-2 border border-zinc-800 text-zinc-400 hover:text-red-500 rounded hover:bg-red-950/10" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 8. Inbox Contacts View */}
            {activeSubTab === 'contacts' && (
              <motion.div key="contacts" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <h2 className="font-display font-extrabold text-xl text-white">Comms Message Inbox</h2>
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div 
                      key={msg.id} 
                      className={`p-5 rounded-xl border relative overflow-hidden transition-all duration-300 ${
                        msg.isRead 
                          ? 'bg-zinc-900/20 border-zinc-900 text-zinc-400' 
                          : 'bg-red-950/10 border-red-900/30 text-zinc-200 glow-border-red shadow-inner'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-display font-bold text-white text-sm">{msg.name}</h4>
                          <span className="font-mono text-[10px] text-zinc-500">{msg.email}</span>
                        </div>
                        <div className="flex space-x-2 items-center">
                          <span className="font-mono text-[9px] text-zinc-600">
                            {new Date(msg.createdAt).toLocaleDateString()}
                          </span>
                          {!msg.isRead && (
                            <button onClick={() => handleMarkMessageRead(msg.id)} className="p-1 border border-zinc-800 hover:border-red-500 text-red-500 bg-zinc-950 rounded text-[9px] font-mono uppercase tracking-wider">
                              Mark Read
                            </button>
                          )}
                          <button onClick={() => handleCrudDelete('/api/contacts', msg.id)} className="p-1 border border-zinc-800 text-zinc-500 hover:text-red-500 hover:border-red-500/20 rounded">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <p className="font-mono text-[10px] text-red-500 font-semibold uppercase mb-1">Subject: {msg.subject}</p>
                      <p className="text-xs font-sans leading-relaxed text-zinc-300">{msg.message}</p>
                    </div>
                  ))}

                  {messages.length === 0 && (
                    <div className="text-center py-12 text-zinc-500 font-mono text-xs">
                      INBOX EMPTY // NO RECEIVED COMMUNICATIONS
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* 9. Backup & Restore Panel */}
            {activeSubTab === 'backup' && (
              <motion.div key="backup" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                <div>
                  <h2 className="font-display font-extrabold text-xl text-white mb-2">System Backups & Database Tools</h2>
                  <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                    Download complete encrypted database snapshots or import structured logs backup file payloads to align states.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  
                  {/* Backup export download */}
                  <div className="glass-card border border-zinc-900 p-5 rounded-xl space-y-4">
                    <h3 className="font-display font-bold text-sm text-white">Download Database Backup</h3>
                    <p className="text-zinc-500 text-[11px] font-sans leading-normal">
                      Export all tables and contents (profiles, skills, projects, certificates, blogs, timeline, tasks, logs) in a consolidated .json backup file.
                    </p>
                    <button 
                      onClick={handleBackupExport}
                      className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white font-mono text-[10px] font-bold uppercase tracking-wider rounded-lg flex items-center space-x-1.5 cursor-pointer shadow-[0_0_10px_rgba(239,68,68,0.2)]"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download JSON</span>
                    </button>
                  </div>

                  {/* Backup restore upload */}
                  <div className="glass-card border border-zinc-900 p-5 rounded-xl space-y-4 relative overflow-hidden">
                    <h3 className="font-display font-bold text-sm text-white">Import Database Backup</h3>
                    <p className="text-zinc-500 text-[11px] font-sans leading-normal">
                      Upload a previously exported database .json file to instantly replace the current tables structure.
                    </p>
                    <div className="relative">
                      <input 
                        type="file" 
                        accept=".json"
                        onChange={handleBackupRestore}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                      />
                      <button className="px-4 py-2.5 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-lg text-[10px] font-mono uppercase tracking-wider flex items-center space-x-1.5">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Select JSON File</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Audit Logs Viewer inside Backup */}
                <div className="space-y-3.5">
                  <div className="flex items-center space-x-2 text-zinc-500 pl-1 font-mono text-[10px] font-bold uppercase tracking-widest">
                    <Terminal className="w-4 h-4 text-red-500" />
                    <span>Live Audit Logs Terminal</span>
                  </div>
                  <div className="bg-black/90 border border-zinc-900 font-mono text-[10px] text-zinc-400 p-4 rounded-xl h-48 overflow-y-auto space-y-1.5 shadow-inner">
                    {activities.map((act) => (
                      <p key={act.id} className="leading-relaxed">
                        <span className="text-zinc-600">[{new Date(act.createdAt).toLocaleTimeString()}]</span>{' '}
                        <span className="text-red-500">[{act.type.toUpperCase()}]</span>{' '}
                        <span className="text-zinc-300">{act.description}</span>{' '}
                        {act.details && <span className="text-zinc-500">({act.details})</span>}
                      </p>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
