import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Github, Linkedin, ArrowRight, FileText, Compass, Briefcase, Mail, Instagram } from 'lucide-react';
import { Profile } from '../types';

interface HeroProps {
  profile: Profile;
  onNavigate: (tab: string) => void;
  lang: 'en' | 'id';
}

export default function Hero({ profile, onNavigate, lang }: HeroProps) {
  const [coords, setCoords] = useState({ x: 0, y: 0 });
  const [subIdx, setSubIdx] = useState(0);
  const [currentText, setCurrentText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  
  const containerRef = useRef<HTMLDivElement>(null);

  // Subtitles typewriter loop
  const subtitles = profile.subtitles || ['Full Stack Developer', 'UI/UX Engineer', 'DevOps Specialist'];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    const fullText = subtitles[subIdx];

    const type = () => {
      if (!isDeleting) {
        setCurrentText(fullText.substring(0, currentText.length + 1));
        if (currentText === fullText) {
          timer = setTimeout(() => setIsDeleting(true), 1500); // Wait before deleting
        } else {
          timer = setTimeout(type, 100);
        }
      } else {
        setCurrentText(fullText.substring(0, currentText.length - 1));
        if (currentText === '') {
          setIsDeleting(false);
          setSubIdx((prev) => (prev + 1) % subtitles.length);
        } else {
          timer = setTimeout(type, 50);
        }
      }
    };

    timer = setTimeout(type, 100);
    return () => clearTimeout(timer);
  }, [currentText, isDeleting, subIdx, subtitles]);

  // Track mouse coordinates for premium 3D Parallax Tilt effect
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const { left, top, width, height } = containerRef.current.getBoundingClientRect();
      const x = (e.clientX - left - width / 2) / (width / 2); // normalize -1 to 1
      const y = (e.clientY - top - height / 2) / (height / 2); // normalize -1 to 1
      setCoords({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section
      ref={containerRef}
      id="hero-section"
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden pt-20 grid-bg noise-bg bg-[#0A0A0A]"
    >
      {/* Huge Backlit low opacity text: AHMAD */}
      <div className="absolute inset-0 flex items-center justify-center select-none pointer-events-none z-0">
        <motion.h1
          style={{
            x: coords.x * -45,
            y: coords.y * -45,
          }}
          className="font-display font-black text-[15vw] sm:text-[18vw] leading-none text-white/[0.02] tracking-widest text-center select-none pointer-events-none uppercase"
        >
          AHMAD
        </motion.h1>
      </div>

      {/* Floating red neon glowing background spheres */}
      <div 
        className="absolute w-[350px] sm:w-[500px] h-[350px] sm:h-[500px] rounded-full bg-[#FF3333]/4 blur-[120px] pointer-events-none"
        style={{
          transform: `translate(${coords.x * 30}px, ${coords.y * 30}px)`,
          top: '25%',
          left: '10%'
        }}
      />
      <div 
        className="absolute w-[250px] sm:w-[400px] h-[250px] sm:h-[400px] rounded-full bg-[#FF3333]/3 blur-[100px] pointer-events-none"
        style={{
          transform: `translate(${coords.x * -25}px, ${coords.y * -25}px)`,
          bottom: '15%',
          right: '15%'
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center py-12">
        
        {/* HERO LEFT INTRO DETAILS */}
        <div className="lg:col-span-7 flex flex-col items-center lg:items-start text-center lg:text-left space-y-6 sm:space-y-8">
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center space-x-2.5 px-3 py-1.5 rounded-full bg-[#FF3333]/5 border border-[#FF3333]/20 shadow-[0_0_15px_rgba(255,51,51,0.05)] font-mono text-[10px] tracking-widest text-[#FF3333] uppercase"
          >
            <span className="w-1.5 h-1.5 bg-[#FF3333] rounded-full animate-ping" />
            <span>{lang === 'en' ? 'SYSTEM ONLINE: READY TO BUILD' : 'SISTEM ONLINE: SIAP MEMBANGUN'}</span>
          </motion.div>

          <div className="space-y-4">
            <motion.h2
              initial={{ opacity: 0, y: 35 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="text-white/40 font-mono text-xs sm:text-sm tracking-widest uppercase"
            >
              {lang === 'en' ? 'GREETINGS, I AM' : 'SALAM, SAYA'}
            </motion.h2>
            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-4xl sm:text-6xl xl:text-7xl font-display font-extrabold tracking-tight leading-tight text-white"
            >
              {profile.name}
            </motion.h1>

            {/* Subtitle Typewriter Effect Container */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.35 }}
              className="flex items-center justify-center lg:justify-start h-8"
            >
              <span className="text-[#FF3333] font-mono text-base sm:text-lg font-bold tracking-wider uppercase glow-text-red">
                &lt; {currentText}
                <span className="w-2 h-5 bg-[#FF3333] inline-block ml-1 animate-pulse" />
                &nbsp;/&gt;
              </span>
            </motion.div>
          </div>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-white/60 font-light text-sm sm:text-base max-w-xl leading-relaxed font-sans"
          >
            {profile.bio}
          </motion.p>

          {/* Core Interactive Actions */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 w-full sm:w-auto"
          >
            <button
              onClick={() => {
                const projEl = document.getElementById('projects-showcase');
                if (projEl) projEl.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-8 py-4 bg-[#FF3333] hover:bg-[#FF3333]/90 text-white font-mono text-xs font-bold tracking-widest uppercase rounded-lg flex items-center justify-center space-x-2.5 shadow-[0_0_20px_rgba(255,51,51,0.25)] hover:shadow-[0_0_30px_rgba(255,51,51,0.45)] transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
            >
              <span>{lang === 'en' ? 'Explore Projects' : 'Jelajahi Proyek'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('dashboard')}
              className="px-8 py-4 bg-white/5 border border-white/10 hover:border-[#FF3333]/40 text-white/80 hover:text-white font-mono text-xs font-bold tracking-widest uppercase rounded-lg flex items-center justify-center space-x-2.5 transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
            >
              <Compass className="w-4 h-4 text-[#FF3333]" />
              <span>{lang === 'en' ? 'Productivity Hub' : 'Hub Produktivitas'}</span>
            </button>
          </motion.div>

          {/* Social Connections */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.55, duration: 0.6 }}
            className="flex items-center justify-center lg:justify-start space-x-5 pt-4 text-white/40"
          >
            {profile.github && (
              <a href={profile.github} target="_blank" rel="noreferrer" className="hover:text-[#FF3333] hover:scale-110 transition-all duration-200" title="GitHub">
                <Github className="w-5 h-5" />
              </a>
            )}
            {profile.linkedin && (
              <a href={profile.linkedin} target="_blank" rel="noreferrer" className="hover:text-[#FF3333] hover:scale-110 transition-all duration-200" title="LinkedIn">
                <Linkedin className="w-5 h-5" />
              </a>
            )}
            {profile.instagram && (
              <a href={profile.instagram} target="_blank" rel="noreferrer" className="hover:text-[#FF3333] hover:scale-110 transition-all duration-200" title="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
            )}
            <a href="mailto:ahmadyusufsyarifullah@gmail.com" className="hover:text-[#FF3333] hover:scale-110 transition-all duration-200" title="Email Direct">
              <Mail className="w-5 h-5" />
            </a>
          </motion.div>
        </div>

        {/* HERO RIGHT 3D PORTRAIT VIEWPORT */}
        <div className="lg:col-span-5 flex items-center justify-center relative">
          
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            style={{
              rotateX: coords.y * -15,
              rotateY: coords.x * 15,
              transformStyle: 'preserve-3d'
            }}
            className="relative w-72 h-72 sm:w-96 sm:h-96 rounded-2xl flex items-center justify-center border border-white/10 bg-[#0D0D0D]/95 shadow-[0_0_50px_rgba(255,51,51,0.1)] p-4 group cursor-grab active:cursor-grabbing overflow-hidden"
          >
            {/* Ambient Red Glow Halo behind image */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#FF3333]/5 via-[#FF3333]/2 to-transparent opacity-60 group-hover:opacity-100 transition-opacity duration-500" />
            
            {/* Custom Interactive Grid Pattern overlay inside portrait frame */}
            <div className="absolute inset-0 grid-bg opacity-15 group-hover:opacity-25 transition-opacity pointer-events-none" />

            {/* Custom beautiful digital avatar backdrop with cinematic light simulation */}
            <div className="relative w-full h-full rounded-xl bg-[#0A0A0A] border border-white/5 overflow-hidden flex flex-col items-center justify-center p-6 text-center">
              
              {/* Outer light beam effect */}
              <div className="absolute top-0 left-1/4 w-1/2 h-full bg-gradient-to-b from-[#FF3333]/5 via-transparent to-transparent rotate-12 blur-md" />
              
              {/* Decorative elements */}
              <div className="absolute top-2 left-3 font-mono text-[8px] text-[#FF3333]/40 tracking-widest">
                CORE_VM // ACTIVE_SYS
              </div>
              <div className="absolute bottom-2 right-3 font-mono text-[8px] text-white/30 tracking-wider">
                COORDINATES: {coords.x.toFixed(2)}, {coords.y.toFixed(2)}
              </div>

              {/* Glowing core orb or profile photo placeholder */}
              <div className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full border border-white/10 bg-white/5 p-2 shadow-[0_0_30px_rgba(255,51,51,0.15)] mb-6 flex items-center justify-center group-hover:scale-105 transition-transform duration-300">
                <div className="absolute -inset-1 bg-[#FF3333]/10 rounded-full blur animate-pulse" />
                <div className="relative w-full h-full rounded-full bg-[#0D0D0D] flex items-center justify-center overflow-hidden">
                  {profile.avatar ? (
                    <img src={profile.avatar} alt={profile.name} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-[#FF3333] font-display font-extrabold text-4xl sm:text-5xl tracking-widest glow-text-red">AYS</span>
                  )}
                </div>
              </div>

              <h3 className="text-white font-display font-bold text-lg tracking-wider mb-1">{profile.name}</h3>
              <p className="text-white/40 font-mono text-[10px] uppercase tracking-widest">Enterprise Full Stack Engineer</p>
              
              {/* Cybernetic active state light bar */}
              <div className="flex items-center space-x-1.5 mt-4">
                <span className="w-1.5 h-1.5 bg-[#FF3333] rounded-full animate-ping" />
                <span className="text-[10px] font-mono tracking-widest text-[#FF3333]/80 font-medium">LIVENESS: SYNC_OK</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
