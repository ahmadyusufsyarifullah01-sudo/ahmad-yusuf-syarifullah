import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send, CheckCircle, AlertCircle, Phone, Mail, MapPin, Loader2 } from 'lucide-react';

interface ContactFormProps {
  lang: 'en' | 'id';
  onNewMessageSent: () => void;
}

export default function ContactForm({ lang, onNewMessageSent }: ContactFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setSubmitStatus('error');
      setStatusMessage(lang === 'en' ? 'Please fill in all required fields.' : 'Silakan isi semua kolom wajib.');
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const res = await fetch('/api/contacts/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      const data = await res.json();
      if (res.ok) {
        setSubmitStatus('success');
        setStatusMessage(lang === 'en' ? 'Message sent successfully! Ahmad will get back to you soon.' : 'Pesan berhasil dikirim! Ahmad akan segera menghubungi Anda.');
        setFormData({ name: '', email: '', subject: '', message: '' });
        onNewMessageSent(); // Trigger navbar notifications reload
      } else {
        throw new Error(data.error || 'Server error');
      }
    } catch (error: any) {
      setSubmitStatus('error');
      setStatusMessage(error.message || (lang === 'en' ? 'Failed to send message. Please try again.' : 'Gagal mengirim pesan. Silakan coba lagi.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 max-w-6xl mx-auto items-start">
      
      {/* DIRECT INFORMATION CONNECTIONS CARD */}
      <div className="lg:col-span-5 space-y-8">
        <div>
          <h3 className="font-display font-extrabold text-2xl text-white mb-3">
            {lang === 'en' ? 'Let\'s collaborate' : 'Mari Berkolaborasi'}
          </h3>
          <p className="text-white/60 text-sm font-sans leading-relaxed">
            {lang === 'en' 
              ? 'Have a project proposal, an enterprise-grade contract, or want to discuss full-stack capabilities? Reach out and initiate our sync.'
              : 'Punya proposal proyek, kontrak standar perusahaan, atau ingin mendiskusikan kemampuan full-stack? Hubungi dan mulailah koordinasi.'}
          </p>
        </div>

        <div className="space-y-4">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-[#FF3333]/10 border border-white/5 rounded-lg text-[#FF3333]">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <p className="font-mono text-xs text-white/40 uppercase tracking-widest font-bold">Email Connection</p>
              <a href="mailto:ahmadyusufsyarifullah@gmail.com" className="text-white/80 hover:text-[#FF3333] font-sans text-sm transition-colors">
                ahmadyusufsyarifullah@gmail.com
              </a>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="p-3 bg-[#FF3333]/10 border border-white/5 rounded-lg text-[#FF3333]">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <p className="font-mono text-xs text-white/40 uppercase tracking-widest font-bold">WhatsApp direct</p>
              <a href="https://wa.me/6281234567890" target="_blank" rel="noreferrer" className="text-white/80 hover:text-[#FF3333] font-sans text-sm transition-colors">
                +62 812-3456-7890
              </a>
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="p-3 bg-[#FF3333]/10 border border-white/5 rounded-lg text-[#FF3333]">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <p className="font-mono text-xs text-white/40 uppercase tracking-widest font-bold">Location Center</p>
              <p className="text-white/80 font-sans text-sm">
                Yogyakarta, Indonesia
              </p>
            </div>
          </div>
        </div>

        {/* Decorative Grid Block representing tech credentials */}
        <div className="border border-white/5 bg-[#0D0D0D]/50 p-4 rounded-xl font-mono text-[10px] text-white/40 space-y-1 shadow-inner relative overflow-hidden">
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-[#FF3333]/5 rounded-full blur-xl pointer-events-none" />
          <p className="text-[#FF3333] font-bold">SECURE ENCRYPTED CONTACT TUNNEL</p>
          <p>PGP_FINGERPRINT: 4D78 E9F1 CB10 094E</p>
          <p>STATUS: SECURITY_PASSTHROUGH_OK</p>
          <p>HOST_IP: 0.0.0.0 (SSL_VERIFIED)</p>
        </div>
      </div>

      {/* SECURE SUBMISSION FORM CARD */}
      <div className="lg:col-span-7 bg-[#0D0D0D] border border-white/5 rounded-xl p-6 sm:p-8 shadow-2xl relative">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="block text-xs font-mono text-white/50 uppercase tracking-widest font-bold" htmlFor="contact-name">
                {lang === 'en' ? 'Full Name' : 'Nama Lengkap'} <span className="text-[#FF3333]">*</span>
              </label>
              <input
                id="contact-name"
                name="name"
                type="text"
                required
                value={formData.name}
                onChange={handleChange}
                placeholder={lang === 'en' ? 'e.g. John Doe' : 'misal: John Doe'}
                className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-[#FF3333] focus:ring-1 focus:ring-[#FF3333]/15 transition-all shadow-inner"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-mono text-white/50 uppercase tracking-widest font-bold" htmlFor="contact-email">
                {lang === 'en' ? 'Email Address' : 'Alamat Email'} <span className="text-[#FF3333]">*</span>
              </label>
              <input
                id="contact-email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleChange}
                placeholder="johndoe@enterprise.com"
                className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-[#FF3333] focus:ring-1 focus:ring-[#FF3333]/15 transition-all shadow-inner"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-mono text-white/50 uppercase tracking-widest font-bold" htmlFor="contact-subject">
              {lang === 'en' ? 'Subject / Goal' : 'Subjek / Tujuan'}
            </label>
            <input
              id="contact-subject"
              name="subject"
              type="text"
              value={formData.subject}
              onChange={handleChange}
              placeholder={lang === 'en' ? 'e.g. Enterprise Solution Development' : 'misal: Kerja Sama Pengembangan Aplikasi'}
              className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-[#FF3333] focus:ring-1 focus:ring-[#FF3333]/15 transition-all shadow-inner"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-mono text-white/50 uppercase tracking-widest font-bold" htmlFor="contact-message">
              {lang === 'en' ? 'Secure Message' : 'Pesan Aman'} <span className="text-[#FF3333]">*</span>
            </label>
            <textarea
              id="contact-message"
              name="message"
              required
              rows={5}
              value={formData.message}
              onChange={handleChange}
              placeholder={lang === 'en' ? 'Describe your project context, timelines, or specifications...' : 'Jelaskan konteks proyek, lini masa, atau spesifikasi Anda...'}
              className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-[#FF3333] focus:ring-1 focus:ring-[#FF3333]/15 transition-all shadow-inner resize-none"
            />
          </div>

          {/* Alert messages feedback */}
          {submitStatus !== 'idle' && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-lg flex items-start space-x-3 text-xs ${
                submitStatus === 'success' 
                  ? 'bg-emerald-950/20 border border-emerald-500/20 text-emerald-400' 
                  : 'bg-red-950/20 border border-red-500/20 text-red-400'
              }`}
            >
              {submitStatus === 'success' ? <CheckCircle className="w-4 h-4 flex-shrink-0" /> : <AlertCircle className="w-4 h-4 flex-shrink-0" />}
              <span>{statusMessage}</span>
            </motion.div>
          )}

          {/* Secure Transmit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 bg-[#FF3333] hover:bg-[#FF3333]/90 text-white font-mono text-xs font-bold tracking-widest uppercase rounded-lg flex items-center justify-center space-x-2 shadow-[0_0_15px_rgba(255,51,51,0.2)] hover:shadow-[0_0_25px_rgba(255,51,51,0.4)] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>{lang === 'en' ? 'Transmitting...' : 'Mengirimkan...'}</span>
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span>{lang === 'en' ? 'Transmit Message' : 'Kirimkan Pesan'}</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
