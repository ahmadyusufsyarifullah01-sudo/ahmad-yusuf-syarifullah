import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, X, Bell, Globe, LogIn, LogOut, ShieldAlert, Laptop, 
  Terminal, Search, Settings, HelpCircle, FileText
} from 'lucide-react';
import { NotificationItem } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: 'en' | 'id';
  setLang: (lang: 'en' | 'id') => void;
  isAdmin: boolean;
  onLoginClick: () => void;
  onLogout: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  isAdmin,
  onLoginClick,
  onLogout,
  notifications,
  onMarkAllRead
}: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Track page scrolling for transparency change
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { id: 'portfolio', label: lang === 'en' ? 'Portfolio' : 'Portofolio' },
    { id: 'dashboard', label: lang === 'en' ? 'Productivity Hub' : 'Hub Produktivitas' },
    { id: 'blogs', label: lang === 'en' ? 'Insights' : 'Blog & Opini' },
    { id: 'gallery', label: lang === 'en' ? 'Art Gallery' : 'Galeri Seni' },
  ];

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 w-full z-40 transition-all duration-300 ${
        scrolled 
          ? 'bg-[#0D0D0D]/90 backdrop-blur-md border-b border-white/10 shadow-lg' 
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* LOGO */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('portfolio')}>
          <div className="w-9 h-9 border border-[#FF3333] flex items-center justify-center bg-black/50 rotate-45 hover:scale-110 transition-transform shadow-[0_0_12px_rgba(255,51,51,0.3)]">
            <span className="text-[#FF3333] font-display font-bold text-sm -rotate-45">AY</span>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2">
            <span className="font-display font-black text-lg tracking-tighter text-white hover:text-[#FF3333] transition-colors leading-none">
              A.YUSUF
            </span>
            <span className="text-white/30 font-mono text-[9px] tracking-widest hidden sm:block uppercase">
              / PRINCIPAL ENGINEER
            </span>
          </div>
        </div>

        {/* DESKTOP NAVIGATION TABS */}
        <nav className="hidden md:flex space-x-1 bg-[#141414]/80 p-1 rounded-full border border-white/5">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative px-4 py-2 rounded-full text-[10px] font-mono tracking-widest uppercase transition-colors duration-300 ${
                activeTab === item.id 
                  ? 'text-white font-medium' 
                  : 'text-white/50 hover:text-white'
              }`}
            >
              {activeTab === item.id && (
                <motion.div
                  layoutId="active-nav"
                  className="absolute inset-0 bg-[#FF3333] rounded-full shadow-[0_0_15px_rgba(255,51,51,0.4)]"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative z-10">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* SYSTEM ACTIONS UTILITIES */}
        <div className="flex items-center space-x-3">
          
          {/* LAN SWITCHER */}
          <button
            onClick={() => setLang(lang === 'en' ? 'id' : 'en')}
            className="p-2 text-white/60 hover:text-white transition-colors duration-200 border border-white/5 rounded-lg hover:bg-white/5 flex items-center space-x-1"
            title={lang === 'en' ? 'Ubah ke Bahasa Indonesia' : 'Switch to English'}
          >
            <Globe className="w-4 h-4 text-[#FF3333]" />
            <span className="text-[10px] font-mono tracking-wider uppercase font-semibold hidden md:inline">
              {lang === 'en' ? 'EN' : 'ID'}
            </span>
          </button>

          {/* NOTIFICATION CENTER */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 text-white/60 hover:text-white transition-colors duration-200 border border-white/5 rounded-lg hover:bg-white/5 relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#FF3333] rounded-full animate-pulse shadow-[0_0_8px_rgba(255,51,51,0.8)]" />
              )}
            </button>

            {/* Notification Dropdown Container */}
            <AnimatePresence>
              {showNotifications && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowNotifications(false)} />
                  <motion.div
                    initial={{ opacity: 0, y: 15, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 15, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-3 w-80 glass-card rounded-xl border border-white/10 shadow-2xl p-4 z-20"
                  >
                    <div className="flex justify-between items-center mb-3 pb-2 border-b border-white/10">
                      <span className="text-[10px] font-mono font-bold tracking-wider text-white uppercase">System Alert Notifications</span>
                      {unreadCount > 0 && (
                        <button 
                          onClick={() => { onMarkAllRead(); setShowNotifications(false); }}
                          className="text-[10px] font-mono text-[#FF3333] hover:underline"
                        >
                          Mark all read
                        </button>
                      )}
                    </div>
                    <div className="max-h-60 overflow-y-auto space-y-2">
                      {notifications.length === 0 ? (
                        <div className="text-center py-6 text-white/40 text-xs font-mono">
                          NO RECENT ALERTS
                        </div>
                      ) : (
                        notifications.map((note) => (
                          <div 
                            key={note.id} 
                            className={`p-2 rounded-lg border text-xs ${
                              note.isRead 
                                ? 'bg-white/5 border-white/5 text-white/50' 
                                : 'bg-[#FF3333]/10 border-[#FF3333]/20 text-white'
                            }`}
                          >
                            <div className="flex justify-between items-start">
                              <span className="font-semibold text-white/95">{note.title}</span>
                              <span className="text-[9px] text-white/40 font-mono">
                                {new Date(note.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="mt-1 text-[11px] leading-relaxed text-white/60">{note.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          {/* ADMIN PORTAL ACCESS TRIGGER */}
          {isAdmin ? (
            <div className="flex items-center space-x-1">
              <button
                onClick={() => setActiveTab('admin')}
                className="px-3 py-1.5 border border-[#FF3333]/30 text-[#FF3333] bg-[#FF3333]/10 hover:bg-[#FF3333] hover:text-white transition-all duration-300 rounded-lg flex items-center space-x-1.5 text-xs font-mono tracking-wider uppercase shadow-[0_0_8px_rgba(255,51,51,0.1)]"
                title="Admin Control Center"
              >
                <Terminal className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">Admin Panel</span>
              </button>
              <button
                onClick={onLogout}
                className="p-2 border border-white/5 text-white/60 hover:text-[#FF3333] hover:border-[#FF3333]/20 rounded-lg hover:bg-white/5"
                title="Logout Account"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onLoginClick}
              className="p-2 border border-white/5 text-white/60 hover:text-[#FF3333] hover:border-[#FF3333]/20 rounded-lg hover:bg-white/5 transition-all"
              title="Admin Authentication"
            >
              <LogIn className="w-4 h-4" />
            </button>
          )}

          {/* MOBILE MENU TOGGLE */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 text-white/60 hover:text-white transition-colors duration-200 border border-white/5 rounded-lg hover:bg-white/5 md:hidden"
            title="Toggle Menu"
          >
            {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* MOBILE DRAWER */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-[#0D0D0D] border-b border-white/10"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsOpen(false);
                  }}
                  className={`block w-full text-left px-4 py-3 rounded-xl font-mono text-xs tracking-widest uppercase transition-colors ${
                    activeTab === item.id 
                      ? 'bg-[#FF3333]/10 border border-[#FF3333]/30 text-white font-semibold' 
                      : 'text-white/60 hover:bg-white/5 border border-transparent'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
