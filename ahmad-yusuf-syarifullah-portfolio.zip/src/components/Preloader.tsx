import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface PreloaderProps {
  onComplete: () => void;
}

export default function Preloader({ onComplete }: PreloaderProps) {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('BOOTING PORTFOLIO CORE...');
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const textIntervals = [
      { prg: 20, txt: 'ESTABLISHING DATA TUNNEL...' },
      { prg: 45, txt: 'COMPILING ENTERPRISE LAYER...' },
      { prg: 70, txt: 'INJECTING GSAP TIMELINES...' },
      { prg: 90, txt: 'SYNCHRONIZING PRODUCTIVITY DASHBOARD...' },
      { prg: 100, txt: 'SECURE CORE: OPERATIONAL' }
    ];

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            setIsVisible(false);
            setTimeout(() => {
              onComplete();
            }, 800);
          }, 600);
          return 100;
        }

        const nextProgress = prev + Math.floor(Math.random() * 8) + 2;
        const bounded = Math.min(nextProgress, 100);

        // Update text according to progress
        const textObj = textIntervals.find((item) => bounded <= item.prg);
        if (textObj) {
          setLoadingText(textObj.txt);
        }

        return bounded;
      });
    }, 80);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          id="preloader-overlay"
          initial={{ opacity: 1 }}
          exit={{ 
            y: '-100%',
            opacity: 0,
            transition: { duration: 0.8, ease: [0.76, 0, 0.24, 1] } 
          }}
          className="fixed inset-0 z-50 bg-[#0A0A0A] flex flex-col items-center justify-center p-6 grid-bg noise-bg"
        >
          {/* Main Visual Logo/Indicator */}
          <div className="relative flex flex-col items-center max-w-md w-full">
            
            {/* Glowing Red Aura */}
            <div className="absolute -inset-10 bg-[#FF3333]/10 rounded-full blur-3xl animate-pulse-slow pointer-events-none" />
 
            {/* Glowing Diamond Emblem */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="w-16 h-16 border-2 border-[#FF3333] rotate-45 flex items-center justify-center bg-black/40 mb-12 shadow-[0_0_20px_rgba(255,51,51,0.25)]"
            >
              <span className="text-[#FF3333] font-display font-bold text-2xl -rotate-45">AY</span>
            </motion.div>
 
            {/* Progress Percentage */}
            <motion.div 
              id="preloader-percentage"
              className="font-mono text-5xl font-bold tracking-widest text-white mb-3"
            >
              {progress}%
            </motion.div>
 
            {/* Console Typewriter Loading Text */}
            <div className="font-mono text-[10px] text-[#FF3333]/90 tracking-widest uppercase mb-8 h-4 text-center font-bold">
              {loadingText}
            </div>
 
            {/* Sleek Progress Bar Container */}
            <div className="w-full bg-white/5 border border-white/10 rounded-full h-[6px] overflow-hidden relative">
              <motion.div
                id="preloader-bar"
                className="bg-[#FF3333] h-full rounded-full shadow-[0_0_10px_rgba(255,51,51,0.5)]"
                initial={{ width: '0%' }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>

            {/* System Specs Footer */}
            <div className="absolute bottom-[-100px] flex justify-between w-full font-mono text-[10px] text-zinc-600 tracking-wider">
              <span>SYSTEM: NODEJS_V22</span>
              <span>HOST: CLOUD_RUN_SG</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
