import fs from 'fs';
import path from 'path';
import { 
  User, Profile, Skill, Project, Certificate, Blog, 
  Experience, Education, GalleryItem, ContactMessage, 
  SocialLink, Setting, Activity, NotificationItem, Task, LearningLog
} from '../src/types';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Helper to hash passwords without external deps (simple but secure SHA-256)
import crypto from 'crypto';
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export interface DatabaseSchema {
  users: User[];
  profiles: Profile[];
  skills: Skill[];
  projects: Project[];
  certificates: Certificate[];
  blogs: Blog[];
  experiences: Experience[];
  education: Education[];
  gallery: GalleryItem[];
  contacts: ContactMessage[];
  social_links: SocialLink[];
  settings: Setting[];
  activities: Activity[];
  notifications: NotificationItem[];
  tasks: Task[];
  learning_logs: LearningLog[];
}

const defaultSchema: DatabaseSchema = {
  users: [
    {
      id: 'admin-1',
      username: 'admin',
      email: 'ahmadyusufsyarifullah@gmail.com',
      role: 'admin',
      passwordHash: hashPassword('password'), // default password: password
      createdAt: new Date().toISOString()
    }
  ],
  profiles: [
    {
      id: 'profile-1',
      name: 'Ahmad Yusuf Syarifullah',
      title: 'Enterprise Full Stack Developer & UI/UX Designer',
      subtitles: ['Full Stack Developer', 'UI/UX Engineer', 'DevOps & Cloud Specialist', 'AI Integrations Lead'],
      bio: 'Crafting beautiful, high-performance, and secure web applications with standard enterprise-grade architectures. Specializing in Node.js, React, TypeScript, and modern deployment pipelines.',
      avatar: '', // Base64 placeholder or nice default generated
      location: 'Yogyakarta, Indonesia',
      email: 'ahmadyusufsyarifullah@gmail.com',
      phone: '+62 812-3456-7890',
      github: 'https://github.com/ahmadyusufsyarifullah01-sudo',
      linkedin: 'https://linkedin.com/in/ahmadyusufsyarifullah',
      instagram: 'https://instagram.com/yunzanigeng'
    }
  ],
  skills: [
    { id: 's-1', name: 'TypeScript & JavaScript', category: 'Frontend', level: 95, icon: 'code' },
    { id: 's-2', name: 'React.js & Next.js', category: 'Frontend', level: 92, icon: 'layout' },
    { id: 's-3', name: 'Node.js & Express', category: 'Backend', level: 90, icon: 'server' },
    { id: 's-4', name: 'Laravel (PHP)', category: 'Backend', level: 85, icon: 'feather' },
    { id: 's-5', name: 'PostgreSQL & MySQL', category: 'Database', level: 88, icon: 'database' },
    { id: 's-6', name: 'Docker & Kubernetes', category: 'DevOps', level: 82, icon: 'container' },
    { id: 's-7', name: 'Google Cloud Platform (GCP)', category: 'DevOps', level: 80, icon: 'cloud' },
    { id: 's-8', name: 'Tailwind CSS & GSAP', category: 'Frontend', level: 95, icon: 'paint-brush' },
    { id: 's-9', name: 'Git & GitHub Actions CI/CD', category: 'Tools', level: 90, icon: 'git-branch' },
    { id: 's-10', name: 'UI/UX Design (Figma)', category: 'Tools', level: 88, icon: 'figma' }
  ],
  projects: [
    {
      id: 'p-1',
      title: 'Apex Productivity Engine',
      description: 'An enterprise productivity suite combining Kanban boards, dynamic learning timers, weather telemetry, and automated GitHub contribution syncing.',
      category: 'Full-Stack Web App',
      tags: ['React', 'Node.js', 'TypeScript', 'TailwindCSS', 'GSAP'],
      image: '',
      githubUrl: 'https://github.com/ahmadyusufsyarifullah01-sudo/ahmad-yusuf-syarifullah',
      demoUrl: 'https://ahmad-yusuf-syarifullah.dev',
      featured: true,
      order: 1
    },
    {
      id: 'p-2',
      title: 'Aura Premium E-Commerce',
      description: 'A luxurious digital storefront crafted with pixel-perfect WebGL, custom transitions, advanced shopping carts, and dynamic Stripe integration.',
      category: 'E-Commerce',
      tags: ['React', 'Three.js', 'Express', 'Stripe API', 'TailwindCSS'],
      image: '',
      githubUrl: 'https://github.com/ahmadyusufsyarifullah01-sudo/aura-luxury-store',
      demoUrl: '#',
      featured: true,
      order: 2
    },
    {
      id: 'p-3',
      title: 'Cosmic Analytics Dashboard',
      description: 'A powerful data visualization board using D3.js and Recharts, monitoring real-time server traffic, database health, and activity logs.',
      category: 'Enterprise Tool',
      tags: ['React', 'D3.js', 'Recharts', 'TailwindCSS', 'TypeScript'],
      image: '',
      githubUrl: 'https://github.com/ahmadyusufsyarifullah01-sudo/cosmic-analytics',
      demoUrl: '#',
      featured: false,
      order: 3
    }
  ],
  certificates: [
    {
      id: 'c-1',
      name: 'Google Cloud Certified Professional Cloud Developer',
      issuer: 'Google Cloud',
      issueDate: '2025-11-20',
      credentialUrl: '#',
      image: ''
    },
    {
      id: 'c-2',
      name: 'Enterprise Application Developer with Laravel',
      issuer: 'Laravel Academy',
      issueDate: '2025-05-15',
      credentialUrl: '#',
      image: ''
    },
    {
      id: 'c-3',
      name: 'Advanced React & Micro-Frontends',
      issuer: 'Frontend Masters',
      issueDate: '2024-08-10',
      credentialUrl: '#',
      image: ''
    }
  ],
  blogs: [
    {
      id: 'b-1',
      title: 'Building Enterprise Full-Stack Apps with Node.js & TypeScript',
      slug: 'building-enterprise-full-stack-apps-nodejs-typescript',
      content: '## Introduction\n\nWhen developing professional web applications, maintaining clean architectures and strict type safety is key to long-term success. Node.js combined with TypeScript offers an exceptionally robust environment for scalable applications.\n\n### Why TypeScript on the Backend?\n- **Type Safety**: Avoid runtime TypeErrors\n- **Autocompletion**: Massive speedup in development\n- **Self-Documentation**: Clean schemas that describe themselves\n\n### Architectural Layers\n1. **Controller Layer**: Parses HTTP requests and calls Services\n2. **Service Layer**: House business logic, validating rules\n3. **Repository Layer**: Interface with databases seamlessly\n\nIn this blog post, we walk through building a production-ready template from scratch.',
      image: '',
      category: 'Backend',
      tags: ['Node.js', 'TypeScript', 'Express', 'Architecture'],
      status: 'published',
      views: 342,
      createdAt: '2026-06-10T12:00:00Z',
      updatedAt: '2026-06-10T12:00:00Z'
    },
    {
      id: 'b-2',
      title: 'The Art of Micro-Animations: Elevating UI from Boring to Award-Winning',
      slug: 'art-of-micro-animations-elevating-ui',
      content: '## The Psychology of Motion\n\nAnimations should never be purely decorative. They act as spatial beacons that guide the user through the interface, explaining hierarchical relationships and signaling successful actions.\n\n### Principles of Polish\n- **Easing**: Standard linear animations feel robotic. Use bespoke cubic-bezier transitions.\n- **Staggering**: Grouped elements should enter with a sequential offset, creating a pleasing wave effect.\n- **Micro-interactions**: Hovering over a magnetic button or dragging a slider should reward the user with satisfying tactile feedback.',
      image: '',
      category: 'UI/UX Design',
      tags: ['GSAP', 'Motion', 'CSS', 'Framer'],
      status: 'published',
      views: 518,
      createdAt: '2026-07-01T15:30:00Z',
      updatedAt: '2026-07-01T15:30:00Z'
    }
  ],
  experiences: [
    {
      id: 'e-1',
      role: 'Senior Full Stack Engineer',
      company: 'TechNovation Solutions',
      location: 'Jakarta, Indonesia',
      startDate: '2024-01-01',
      endDate: 'Present',
      description: 'Leading a core team of engineers in building enterprise cloud portals, designing high-throughput REST APIs, setting up automatic GCP pipelines, and implementing pixel-perfect UI screens in React.',
      current: true
    },
    {
      id: 'e-2',
      role: 'Full Stack Web Developer',
      company: 'CreativeSpace Studio',
      location: 'Yogyakarta, Indonesia',
      startDate: '2022-03-01',
      endDate: '2023-12-31',
      description: 'Crafted bespoke digital products for international clients. Built custom Laravel systems, high-converting React landings, and integrated third-party platforms (Stripe, HubSpot, Twilio).',
      current: false
    }
  ],
  education: [
    {
      id: 'ed-1',
      institution: 'Universitas Gadjah Mada',
      degree: 'Bachelor of Science',
      field: 'Information Technology',
      startDate: '2018-09-01',
      endDate: '2022-07-15',
      gpa: '3.85 / 4.00'
    }
  ],
  gallery: [
    {
      id: 'g-1',
      title: 'Bento UI Dark Mode',
      description: 'UI exploration of a fully modular high-density dashboard.',
      image: '',
      category: 'UI Design'
    },
    {
      id: 'g-2',
      title: 'Neon Cyberpunk Poster',
      description: 'Digital art design fusing high-impact typography with red glows.',
      image: '',
      category: 'Graphic Art'
    }
  ],
  contacts: [],
  social_links: [
    { id: 'sl-1', platform: 'GitHub', url: 'https://github.com/ahmadyusufsyarifullah01-sudo', icon: 'Github' },
    { id: 'sl-2', platform: 'LinkedIn', url: 'https://linkedin.com/in/ahmadyusufsyarifullah', icon: 'Linkedin' },
    { id: 'sl-3', platform: 'Instagram', url: 'https://instagram.com/yunzanigeng', icon: 'Instagram' },
    { id: 'sl-4', platform: 'WhatsApp', url: 'https://wa.me/6281234567890', icon: 'Phone' },
    { id: 'sl-5', platform: 'Email', url: 'mailto:ahmadyusufsyarifullah@gmail.com', icon: 'Mail' }
  ],
  settings: [
    { id: 'st-1', key: 'homepage_hero_title', value: 'AHMAD' },
    { id: 'st-2', key: 'homepage_hero_subtitle', value: 'AHMAD YUSUF SYARIFULLAH' },
    { id: 'st-3', key: 'seo_title', value: 'Ahmad Yusuf Syarifullah | Portfolio' },
    { id: 'st-4', key: 'seo_description', value: 'Enterprise-grade portfolio and productivity center of Ahmad Yusuf Syarifullah.' },
    { id: 'st-5', key: 'seo_keywords', value: 'Full Stack, Developer, Portfolio, Ahmad Yusuf, GSAP, React, Express, Enterprise' }
  ],
  activities: [
    {
      id: 'act-1',
      type: 'system',
      description: 'Database initialized and seeded with enterprise defaults.',
      createdAt: new Date().toISOString()
    }
  ],
  notifications: [
    {
      id: 'not-1',
      title: 'Database Booted',
      message: 'Welcome to your premium dashboard. Your data layer is fully synchronized and running on SQLite/JSON Engine.',
      isRead: false,
      createdAt: new Date().toISOString()
    }
  ],
  tasks: [
    { id: 't-1', title: 'Complete Portfolio Sections (GSAP Revelations)', status: 'in_progress', priority: 'high', createdAt: new Date().toISOString() },
    { id: 't-2', title: 'Add Admin Panel settings panel', status: 'done', priority: 'medium', createdAt: new Date().toISOString() },
    { id: 't-3', title: 'Integrate real-time weather and GitHub status trackers', status: 'todo', priority: 'low', createdAt: new Date().toISOString() }
  ],
  learning_logs: [
    { id: 'l-1', topic: 'Three.js Shaders & WebGL', hours: 4, date: new Date().toISOString().split('T')[0] },
    { id: 'l-2', topic: 'Docker Container Ingress Routing', hours: 3, date: new Date(Date.now() - 86400000).toISOString().split('T')[0] },
    { id: 'l-3', topic: 'GSAP Timelines & Magnetic Snaps', hours: 5, date: new Date(Date.now() - 172800000).toISOString().split('T')[0] }
  ]
};

class FileDatabase {
  private data: DatabaseSchema = defaultSchema;

  constructor() {
    this.load();
  }

  private load() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf8');
        this.data = JSON.parse(fileContent);
        // Ensure all default tables are defined
        for (const key of Object.keys(defaultSchema) as Array<keyof DatabaseSchema>) {
          if (!this.data[key]) {
            (this.data[key] as any) = defaultSchema[key] as any;
          }
        }
      } else {
        this.data = defaultSchema;
        this.save();
      }
    } catch (e) {
      console.error('Error loading file-backed database:', e);
      this.data = defaultSchema;
    }
  }

  public save() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf8');
    } catch (e) {
      console.error('Error saving database:', e);
    }
  }

  public getTable<K extends keyof DatabaseSchema>(table: K): DatabaseSchema[K] {
    this.load();
    return this.data[table];
  }

  public setTable<K extends keyof DatabaseSchema>(table: K, value: DatabaseSchema[K]) {
    this.data[table] = value;
    this.save();
  }

  public getById<K extends keyof DatabaseSchema>(table: K, id: string): any {
    const list = this.getTable(table) as any[];
    return list.find(item => item.id === id) || null;
  }

  public insert<K extends keyof DatabaseSchema>(table: K, item: any): any {
    const list = [...this.getTable(table)] as any[];
    const newItem = {
      id: `${table.substring(0, 3)}-${Date.now()}`,
      createdAt: new Date().toISOString(),
      ...item
    };
    list.push(newItem);
    this.setTable(table, list as any);
    
    // Add activity log
    this.logActivity('crud', `Created item in ${table}`, `ID: ${newItem.id}`);
    
    return newItem;
  }

  public update<K extends keyof DatabaseSchema>(table: K, id: string, item: any): any {
    const list = [...this.getTable(table)] as any[];
    const idx = list.findIndex(x => x.id === id);
    if (idx === -1) throw new Error(`Item ${id} not found in ${table}`);
    
    const updatedItem = {
      ...list[idx],
      ...item,
      updatedAt: new Date().toISOString()
    };
    list[idx] = updatedItem;
    this.setTable(table, list as any);
    
    // Add activity log
    this.logActivity('crud', `Updated item in ${table}`, `ID: ${id}`);

    return updatedItem;
  }

  public delete<K extends keyof DatabaseSchema>(table: K, id: string): boolean {
    const list = [...this.getTable(table)] as any[];
    const filtered = list.filter(x => x.id !== id);
    if (list.length === filtered.length) return false;
    this.setTable(table, filtered as any);
    
    // Add activity log
    this.logActivity('crud', `Deleted item in ${table}`, `ID: ${id}`);

    return true;
  }

  public logActivity(type: 'system' | 'auth' | 'crud' | 'message', description: string, details?: string, username?: string) {
    const logs = [...this.getTable('activities')];
    const newLog: Activity = {
      id: `act-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type,
      description,
      details,
      username,
      createdAt: new Date().toISOString()
    };
    logs.unshift(newLog); // push to front (most recent)
    // Keep max 100 logs
    this.data.activities = logs.slice(0, 100);
    this.save();
  }

  public addNotification(title: string, message: string) {
    const notes = [...this.getTable('notifications')];
    const newNote: NotificationItem = {
      id: `not-${Date.now()}`,
      title,
      message,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    notes.unshift(newNote);
    this.data.notifications = notes.slice(0, 50);
    this.save();
  }
}

export const db = new FileDatabase();
